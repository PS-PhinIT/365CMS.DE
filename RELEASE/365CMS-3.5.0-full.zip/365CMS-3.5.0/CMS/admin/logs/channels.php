<?php
declare(strict_types=1);

require dirname(__DIR__) . '/logs-channels.php';
