<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * View: Theme Editor Fallback
 *
 * @var array<string, mixed> $data
 */

$state = is_array($data ?? null) ? $data : [];
$activeThemeSlug = (string) ($state['activeThemeSlug'] ?? '');
$reason = (string) ($state['reason'] ?? 'Das aktive Theme stellt keinen eigenen Customizer bereit.');
$reasonCode = (string) ($state['reasonCode'] ?? 'customizer_missing');
$reasonHint = (string) ($state['reasonHint'] ?? '');
$links = is_array($state['links'] ?? null) ? $state['links'] : [];
$constraints = is_array($state['constraints'] ?? null) ? $state['constraints'] : [];
$expectedCustomizerPath = (string) ($state['expectedCustomizerPath'] ?? ($constraints['expected_relative_path'] ?? 'admin/customizer.php'));
$blockedFunctions = array_values(array_filter(array_map('strval', is_array($constraints['blocked_functions'] ?? null) ? $constraints['blocked_functions'] : [])));
$themesLink = (string) ($links['themes'] ?? '/admin/themes');
$explorerLink = (string) ($links['explorer'] ?? '/admin/theme-explorer');
?>
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="content-listing-header">
            <div>
                <div class="page-pretitle">Themes</div>
                <h2 class="page-title mb-1">Theme Editor</h2>
                <div class="content-listing-header__meta">
                    <span>Fallback aktiv</span>
                    <?php if ($activeThemeSlug !== ''): ?><span>Theme: <?php echo htmlspecialchars($activeThemeSlug, ENT_QUOTES); ?></span><?php endif; ?>
                </div>
            </div>
            <div class="admin-section-toolbar__actions">
                <a href="<?php echo htmlspecialchars($themesLink, ENT_QUOTES); ?>" class="btn btn-outline-secondary btn-sm">Theme-Verwaltung</a>
            </div>
        </div>
    </div>
</div>

<div class="page-body">
<div class="container-xl">
    <?php
    $alertData = [
        'type' => 'warning',
        'message' => $reason,
        'details' => array_values(array_filter([
            $activeThemeSlug !== '' ? 'Aktives Theme: ' . $activeThemeSlug : '',
            'Erwarteter Pfad: ' . $expectedCustomizerPath,
            $reasonHint !== '' ? $reasonHint : '',
        ])),
    ];
    $alertDismissible = false;
    $alertMarginClass = 'mb-3';
    require __DIR__ . '/../partials/flash-alert.php';
    ?>

    <?php
    $alertData = [
        'type' => 'secondary',
        'message' => 'Der Theme Editor nutzt hier bewusst den sicheren Fallback statt eine unsichere Customizer-Datei direkt zu laden.',
        'details' => array_values(array_filter([
            !empty($constraints['fallback_view']) ? 'Fallback-View: ' . (string) $constraints['fallback_view'] : '',
            'Nächster sicherer Pfad: ' . $expectedCustomizerPath,
            !empty($constraints['max_customizer_label']) ? 'Inline-Limit: ' . (string) $constraints['max_customizer_label'] : '',
            $blockedFunctions !== [] ? 'Blockierte Funktionen: ' . implode(', ', $blockedFunctions) : '',
        ])),
    ];
    $alertDismissible = false;
    $alertMarginClass = 'mb-3';
    require __DIR__ . '/../partials/flash-alert.php';
    ?>

    <div class="card admin-content-card">
        <div class="card-body">
            <p class="mb-3">Falls das Theme einen eigenen Customizer erhalten soll, erwartet der Admin-Pfad eine sichere Datei <code><?php echo htmlspecialchars($expectedCustomizerPath, ENT_QUOTES); ?></code> innerhalb des aktiven Theme-Verzeichnisses.</p>
            <div class="small text-muted mb-3">
                Grundcode: <code><?php echo htmlspecialchars($reasonCode, ENT_QUOTES); ?></code>
                <?php if ($activeThemeSlug !== ''): ?> · Theme: <code><?php echo htmlspecialchars($activeThemeSlug, ENT_QUOTES); ?></code><?php endif; ?>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="<?php echo htmlspecialchars($themesLink, ENT_QUOTES); ?>" class="btn btn-primary">Zur Theme-Verwaltung</a>
                <a href="<?php echo htmlspecialchars($explorerLink, ENT_QUOTES); ?>" class="btn btn-outline-secondary">Theme Explorer öffnen</a>
            </div>
        </div>
    </div>
</div>
</div>
