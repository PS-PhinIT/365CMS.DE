<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Media – Kategorien View
 *
 * Erwartet: $data (aus MediaModule::getCategoriesData())
 *           $alert, $csrfToken
 */

$categories = $data['categories'] ?? [];
$systemSlugs = is_array($data['system_slugs'] ?? null) ? $data['system_slugs'] : ['themes', 'plugins', 'assets', 'fonts', 'dl-manager', 'form-uploads', 'member'];
$constraints = is_array($data['constraints'] ?? null) ? $data['constraints'] : [];
$mediaCategoriesConfig = [
    'deleteFormId' => 'deleteCatForm',
    'deleteSlugFieldId' => 'deleteCatSlug',
    'deleteTitle' => 'Kategorie löschen',
    'deleteConfirmText' => 'Löschen',
    'deleteConfirmClass' => 'btn-danger',
    'deleteMessageTemplate' => 'Kategorie {name} wirklich löschen? Die zugeordneten Dateien bleiben erhalten.',
];
?>

<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="content-listing-header">
            <div>
                <div class="page-pretitle">Medienverwaltung</div>
                <h2 class="page-title mb-1">Kategorien</h2>
                <div class="content-listing-header__meta">
                    <span><?php echo count($categories); ?> Kategorien</span>
                    <span><?php echo count($systemSlugs); ?> geschützte System-Slugs</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="page-body">
    <div class="container-xl">

        <?php if (!empty($alert)): ?>
            <?php $alertData = $alert; $alertMarginClass = 'mb-3'; require __DIR__ . '/../partials/flash-alert.php'; ?>
        <?php endif; ?>

        <div class="cms-admin-info-box mb-3" role="note">
            <div class="cms-admin-info-box__head">
                <h3 class="cms-admin-info-box__title">Regeln für Medienkategorien</h3>
            </div>
            <p class="cms-admin-info-box__text">
                Kategorienamen sind bis <?php echo (int)($constraints['category_name_max_length'] ?? 80); ?> Zeichen,
                Slugs bis <?php echo (int)($constraints['category_slug_max_length'] ?? 80); ?> Zeichen erlaubt.
                System-Slugs bleiben geschützt und können hier nicht gelöscht werden.
            </p>
        </div>

        <div class="card content-listing-card content-listing-toolbar mb-3">
            <div class="card-body">
                <div class="content-listing-toolbar__label">Navigation &amp; Aktionen</div>
                <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between">
                    <span class="text-secondary small">Kategorieverwaltung folgt dem klassischen Ablauf Formular links und Liste rechts.</span>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="/admin/media" class="btn btn-sm btn-outline-secondary">Zur Bibliothek</a>
                        <a href="/admin/media?tab=settings" class="btn btn-sm btn-outline-secondary">Medien-Einstellungen</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-entity-layout">
            <div class="content-entity-layout__aside">
                <div class="card">
                    <div class="card-header"><h3 class="card-title">Neue Kategorie</h3></div>
                    <div class="card-body">
                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="action" value="add_category">
                            <div class="mb-3">
                                <label class="form-label" for="catName">Name</label>
                                <input type="text" class="form-control" id="catName" name="name" maxlength="<?php echo (int)($constraints['category_name_max_length'] ?? 80); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="catSlug">Slug</label>
                                <input type="text" class="form-control" id="catSlug" name="slug" maxlength="<?php echo (int)($constraints['category_slug_max_length'] ?? 80); ?>" placeholder="wird automatisch generiert">
                                <small class="form-hint">Nur Kleinbuchstaben, Zahlen und Bindestriche.</small>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Kategorie erstellen</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="content-entity-layout__main">
                <div class="card">
                    <div class="card-header"><h3 class="card-title">Kategorien</h3></div>
                    <?php if (empty($categories)): ?>
                        <div class="card-body">
                            <div class="empty">
                                <p class="empty-title">Keine Kategorien vorhanden</p>
                                <p class="empty-subtitle text-secondary">Erstellen Sie eine neue Kategorie über das Formular links.</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-vcenter card-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>Dateien</th>
                                        <th>Typ</th>
                                        <th class="w-1"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($categories as $cat): ?>
                                        <?php $isSystem = in_array($cat['slug'], $systemSlugs, true); ?>
                                        <tr>
                                            <td class="fw-bold"><?php echo htmlspecialchars($cat['name']); ?></td>
                                            <td class="text-secondary"><?php echo htmlspecialchars($cat['slug']); ?></td>
                                            <td><?php echo (int)($cat['count'] ?? 0); ?></td>
                                            <td>
                                                <?php if ($isSystem): ?>
                                                    <span class="badge bg-blue-lt">System</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary-lt">Benutzerdefiniert</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!$isSystem): ?>
                                                    <button
                                                        type="button"
                                                        class="btn btn-ghost-danger btn-icon btn-sm js-media-category-delete"
                                                        title="Löschen"
                                                        data-delete-slug="<?php echo htmlspecialchars((string) $cat['slug'], ENT_QUOTES); ?>"
                                                        data-delete-name="<?php echo htmlspecialchars((string) $cat['name'], ENT_QUOTES); ?>">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 7l16 0"/><path d="M10 11l0 6"/><path d="M14 11l0 6"/><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"/><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"/></svg>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Delete-Formular -->
<form id="deleteCatForm" method="post" class="d-none">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
    <input type="hidden" name="action" value="delete_category">
    <input type="hidden" name="slug" id="deleteCatSlug">
</form>

<script type="application/json" id="media-categories-config">
<?php echo json_encode($mediaCategoriesConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>
</script>
