import type {} from '../../../typedef';
export default UIManager;
/**
 * @description The UI class is a class that handles operations related to the user interface of SunEditor.
 * - This class sets the editor's style, theme, editor mode, etc., and controls the state of various UI elements.
 */
declare class UIManager {
	/**
	 * @constructor
	 * @param {SunEditor.Kernel} kernel
	 */
	constructor(kernel: SunEditor.Kernel);
	alertModal: HTMLElement;
	alertMessage: HTMLSpanElement;
	toastPopup: HTMLElement;
	toastContainer: Element;
	toastMessage: HTMLSpanElement;
	/**
	 * @description Currently open `Controller` info array — the one registry of open controllers.
	 * - Read it through the query methods (`isInsideController`, `getControllerAt`, `hasFloatingController`);
	 * - entries are added and removed by `Controller` (and `_addInEditorEntry`/`_removeControllerEntry`).
	 * @type {Array<SunEditor.Module.Controller.Info>}
	 */
	opendControllers: Array<SunEditor.Module.Controller.Info>;
	/**
	 * @internal
	 * @description Current Figure container.
	 * @type {?HTMLElement}
	 */
	_figureContainer: HTMLElement | null;
	/**
	 * @description Whether any `SelectMenu` is currently open.
	 * - Read-only: a menu announces itself through {@link setSelectMenuOpen}. Derived from the set of
	 * open instances so an unrelated menu closing cannot clear the flag for a menu that is still open.
	 * @returns {boolean}
	 */
	get selectMenuOn(): boolean;
	/**
	 * @internal
	 * @description `SelectMenu` open-state notification. Called by `SelectMenu.open()` / `.close()`.
	 * @param {*} instance The `SelectMenu` instance changing state
	 * @param {boolean} open `true` on open, `false` on close
	 */
	setSelectMenuOpen(instance: any, open: boolean): void;
	/**
	 * @description Set editor frame styles.
	 * - Define the style of the edit area
	 * - It can also be defined with the `setOptions` method, but the `setEditorStyle` method does not render the editor again.
	 * @param {string} style Style string
	 * @param {?SunEditor.FrameContext} [fc] Frame context
	 */
	setEditorStyle(style: string, fc?: SunEditor.FrameContext | null): void;
	/**
	 * @description Set the theme to the editor
	 * @param {string} theme Theme name
	 */
	setTheme(theme: string): void;
	/**
	 * @description Set direction to `rtl` or `ltr`.
	 * @param {"rtl"|"ltr"} dir `rtl` or `ltr`
	 */
	setDir(dir: 'rtl' | 'ltr'): void;
	/**
	 * @description Switch to or off `ReadOnly` mode.
	 * @param {boolean} value `readOnly` boolean value.
	 * @param {string} [rootKey] Root key
	 */
	readOnly(value: boolean, rootKey?: string): void;
	/**
	 * @description Disables the editor.
	 * @param {string} [rootKey] Root key
	 */
	disable(rootKey?: string): void;
	/**
	 * @description Enables the editor.
	 * @param {string} [rootKey] Root key
	 */
	enable(rootKey?: string): void;
	/**
	 * @description Shows the editor interface.
	 * @param {string} [rootKey] Root key
	 */
	show(rootKey?: string): void;
	/**
	 * @description Hides the editor interface.
	 * @param {string} [rootKey] Root key
	 */
	hide(rootKey?: string): void;
	/**
	 * @description Shows the loading spinner.
	 * @param {string} [rootKey] Root key
	 */
	showLoading(rootKey?: string): void;
	/**
	 * @description Hides the loading spinner.
	 * @param {string} [rootKey] Root key
	 */
	hideLoading(rootKey?: string): void;
	/**
	 * @description  Open the alert panel
	 * @param {string} text alert message
	 * @param {""|"error"|"success"} type alert type
	 */
	alertOpen(text: string, type: '' | 'error' | 'success'): void;
	/**
	 * @description  Close the alert panel
	 */
	alertClose(): void;
	/**
	 * @description Show toast
	 * @param {string} message toast message
	 * @param {number} [duration=1000] duration time(ms)
	 * @param {""|"error"|"success"} [type=""] duration time(ms)
	 */
	showToast(message: string, duration?: number, type?: '' | 'error' | 'success'): void;
	/**
	 * @description Close toast
	 */
	closeToast(): void;
	/**
	 * @description This method disables or enables the toolbar buttons when the `controller` is activated or deactivated.
	 * - When the `controller` is activated, the toolbar buttons are disabled; when the `controller` is deactivated, the buttons are enabled.
	 * @param {boolean} active If `true`, the toolbar buttons will be disabled. If `false`, the toolbar buttons will be enabled.
	 * @returns {boolean} The current state of the controller on disabled buttons.
	 */
	setControllerOnDisabledButtons(active: boolean): boolean;
	/**
	 * @description Whether `target` lies inside an open controller — floating or in-editor.
	 * @param {?Node} target The node to test
	 * @returns {boolean}
	 */
	isInsideController(target: Node | null): boolean;
	/**
	 * @description The open controller whose form contains `target`.
	 * @param {?Node} target The node to test
	 * @returns {?SunEditor.Module.Controller.Info}
	 */
	getControllerAt(target: Node | null): SunEditor.Module.Controller.Info | null;
	/**
	 * @description Whether a floating controller (one in the `carrierWrapper`) is open.
	 * - In-editor entries (`wrapper` controllers, the figure resize frame) don't count.
	 * @returns {boolean}
	 */
	hasFloatingController(): boolean;
	/**
	 * @description Closes every open controller at once — child popups before their parents — and ends the
	 * component selection. The one-step alternative to the level-by-level Esc (see `Controller`'s `escape` option).
	 */
	closeAllControllers(): void;
	/**
	 * @internal
	 * @description Suspends (hides, and protects from closing) or resumes the open floating controllers.
	 * — while a modal is open. In-editor controllers stay under the modal and keep their own lifecycle.
	 * @param {boolean} suspend `true` to suspend, `false` to resume
	 */
	_suspendControllers(suspend: boolean): void;
	/**
	 * @internal
	 * @description Registers an in-editor element that is not a `Controller` (the figure resize frame).
	 * - the core then  moves it with the wysiwyg's inner scroll and hides it with the other controllers. Replaces an earlier entry of the same form.
	 * @param {SunEditor.Module.Controller.Info} info Entry (`notInCarrier: true`, with `inst.__offset` as scroll baseline)
	 */
	_addInEditorEntry(info: SunEditor.Module.Controller.Info): void;
	/**
	 * @internal
	 * @description Removes the registry entry of `form`.
	 * @param {HTMLElement} form The registered form
	 */
	_removeControllerEntry(form: HTMLElement): void;
	/**
	 * @description Activate the transparent background `div` so that other elements are not affected during resizing.
	 * @param {string} cursor cursor css property
	 */
	enableBackWrapper(cursor: string): void;
	/**
	 * @description Disabled background `div`
	 */
	disableBackWrapper(): void;
	/**
	 * @description Closes the currently active controller by delegating to the component's deselect logic.
	 * Use this method to close a single active controller from external code.
	 * @see _offControllers - For closing all open controllers at once (internal use)
	 */
	offCurrentController(): void;
	/**
	 * @description Closes the currently open modal dialog.
	 */
	offCurrentModal(): void;
	/**
	 * @description Get the current figure container only if it is visible (active).
	 * @returns {?HTMLElement} The active figure element or `null`.
	 */
	getVisibleFigure(): HTMLElement | null;
	/**
	 * @description Set the active figure element (image, video) being resized.
	 * @param {?HTMLElement} figure
	 */
	setFigureContainer(figure: HTMLElement | null): void;
	preventToolbarHide(allow: any): void;
	get isPreventToolbarHide(): boolean;
	/**
	 * @param {SunEditor.FrameContext} rt Root target[key] FrameContext
	 */
	/**
	 * @description Block handle instance for external access.
	 * @type {BlockHandle}
	 */
	get blockHandle(): BlockHandle;
	reset(rt: any): void;
	/**
	 * @internal
	 * @description Closes all open controllers except those marked as `fixed` — child popups before their parents —
	 * through their own `close()`, hides the other entries' forms, and resets the controller state.
	 * @see offCurrentController - Public method for closing a single controller via component deselect
	 */
	_offControllers(): void;
	currentControllerName: string;
	/**
	 * @internal
	 * @description Synchronizes floating UI element positions with the current scroll offset.
	 * Called by eventManager when the wysiwyg area is scrolled.
	 * - Adjusts balloon toolbar position based on scroll offset
	 * - Closes controllers if scroll target changes
	 * - Updates line breaker positions
	 * @param {SunEditor.EventWysiwyg} eventWysiwyg - The scroll event source (Window or element with scroll data)
	 */
	_syncScrollPosition(eventWysiwyg: SunEditor.EventWysiwyg): void;
	/**
	 * @internal
	 * @description Repositions all currently open controllers after scroll.
	 * Called by eventManager during container scroll events.
	 * - Triggers drag handle repositioning if active
	 * - Calls _scrollReposition on each open controller
	 */
	_repositionControllers(): void;
	/**
	 * @internal
	 * @description Visible controllers
	 * @param {boolean} value hidden/show
	 * @param {?boolean} [lineBreakShow] Line break hidden/show (default: Follows the value `value`.)
	 */
	_visibleControllers(value: boolean, lineBreakShow?: boolean | null): void;
	setCurrentControllerContext: any;
	/**
	 * @internal
	 * @description Set the disabled button list
	 */
	_initToggleButtons(): void;
	/**
	 * @internal
	 * @description Toggle the disabled state of buttons reserved for Code View.
	 * @param {boolean} isCodeView
	 */
	_toggleCodeViewButtons(isCodeView: boolean): void;
	/**
	 * @internal
	 * @description Toggle the disabled state of buttons when a controller is active.
	 * @param {boolean} isOpen
	 */
	_toggleControllerButtons(isOpen: boolean): void;
	/**
	 * @description Check if the button can be executed in the current state (ReadOnly, etc.)
	 * @param {Node} button
	 * @returns {boolean}
	 */
	isButtonDisabled(button: Node): boolean;
	/**
	 * @internal
	 * @description Updates `placeholder` visibility based on editor state.
	 * Shows `placeholder` when editor is empty, hides it in code view or when content exists.
	 * @param {SunEditor.FrameContext} [fc] - Frame context (defaults to current frameContext)
	 */
	_updatePlaceholder(fc?: SunEditor.FrameContext): void;
	/**
	 * @description Resolves the per-line placeholder text for an empty line from the `placeholder_line` option.
	 * - String option: one hint for every empty line — except list cells and table cells (backward compatible).
	 * - Object option: keyed by tag name or a category sentinel matching the editor's format classification
	 *   ({@link Format#isNormalLine}, `isBrLine`, `isClosureBrLine`, `isBlock`, `isClosureBlock`, list cells).
	 * @param {?Node} line - The (empty) line element.
	 * @param {string|Object<string, string>} opt - The `placeholder_line` option value.
	 * @returns {string} The resolved placeholder text (`''` = none).
	 */
	resolveLinePlaceholder(
		line: Node | null,
		opt:
			| string
			| {
					[x: string]: string;
			  },
	): string;
	/**
	 * @internal
	 * @description Synchronizes frame UI state after content changes.
	 * Coordinates `iframe` height adjustment, `placeholder` visibility, and document type page sync.
	 * @param {SunEditor.FrameContext} fc - Frame context to synchronize
	 */
	_syncFrameState(fc: SunEditor.FrameContext): void;
	/**
	 * @internal
	 * @description Adjusts `iframe` height to match content height.
	 * Handles `auto`-height `iframe`s and manages scrolling based on `maxHeight` option.
	 * @param {SunEditor.FrameContext} fc - Frame context containing the `iframe`
	 */
	_iframeAutoHeight(fc: SunEditor.FrameContext): void;
	/**
	 * @internal
	 * @description Emits the `onResizeEditor` event when editor height changes.
	 * Calculates height from `ResizeObserverEntry` if not provided directly.
	 * @param {SunEditor.FrameContext} fc - Frame context
	 * @param {number} h - Height value (`-1` to calculate from `resizeObserverEntry`)
	 * @param {ResizeObserverEntry|null} resizeObserverEntry - `ResizeObserver` entry for height calculation
	 */
	_emitResizeEvent(fc: SunEditor.FrameContext, h: number, resizeObserverEntry: ResizeObserverEntry | null): void;
	init(): void;
	/**
	 * @internal
	 * @description Destroy the UI instance and release memory
	 */
	_destroy(): void;
	opendModal: any;
	opendBrowser: any;
	#private;
}
import BlockHandle from '../panel/blockHandle.js';
