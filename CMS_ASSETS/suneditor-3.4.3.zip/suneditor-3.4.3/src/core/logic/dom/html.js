import { dom, converter, markdown, numbers, unicode, clipboard, env } from '../../../helper';

const { _d } = env;
const REQUIRED_DATA_ATTRS = 'data-se-[^\\s]+';
const V2_MIG_DATA_ATTRS = '|data-index|data-file-size|data-file-name|data-exp|data-font-size';
const ZWS_RUN_REGEXP = new RegExp(unicode.zeroWidthSpace + '+', 'g');

/**
 * @description All HTML related classes involved in the editing area
 */
class HTML {
	/** @type {SunEditor.Deps} */
	#$;
	#store;

	#frameContext;
	#frameOptions;
	#options;
	#instanceCheck;

	#fontSizeUnitRegExp;
	#isAllowedClassName;
	#allowHTMLComment;
	#disallowedStyleNodesRegExp;
	#htmlCheckWhitelistRegExp;
	#htmlCheckBlacklistRegExp;
	#elementWhitelistRegExp;
	#elementBlacklistRegExp;
	#attributeWhitelistRegExp;
	#attributeBlacklistRegExp;
	#cleanStyleTagKeyRegExp;
	#cleanStyleRegExpMap;
	#textStyleTags;
	#disallowedTagsRegExp;
	#disallowedTagNameRegExp;
	#allowedTagNameRegExp;
	#emptyLineRegExp;
	#brLineBlockRegExp;

	/** @type {Set<string>} */
	#allowedURLProtocols;

	/** @type {Object<string, RegExp>} */
	#attributeWhitelist;
	/** @type {Object<string, RegExp>} */
	#attributeBlacklist;
	/** @type {Object<string, *>} */
	#autoStyleify;

	/**
	 * @constructor
	 * @param {SunEditor.Kernel} kernel
	 */
	constructor(kernel) {
		this.#$ = kernel.$;
		this.#store = kernel.store;

		const options = (this.#options = this.#$.options);
		this.#frameOptions = this.#$.frameOptions;
		this.#frameContext = this.#$.frameContext;
		this.#instanceCheck = this.#$.instanceCheck;

		// members
		this.#isAllowedClassName = function (v) {
			return this.test(v) ? v : '';
		}.bind(options.get('allowedClassName'));

		this.#textStyleTags = options.get('_textStyleTags');
		this.#allowedURLProtocols = new Set(options.get('allowedURLProtocols') || []);

		// clean styles
		const tagStyles = options.get('tagStyles');
		const splitTagStyles = {};
		for (const k in tagStyles) {
			const s = k.split('|');
			for (let i = 0, len = s.length, n; i < len; i++) {
				n = s[i];
				if (!splitTagStyles[n]) splitTagStyles[n] = '';
				else splitTagStyles[n] += '|';
				splitTagStyles[n] += tagStyles[k];
			}
		}

		// A tag with an explicit entry that is also a line/text-style tag inherits the category
		// styles ('@line'/'@text'), so category edits stay effective for it. (e.g. "li")
		const formatLineReg = options.get('formatLine').reg;
		for (const k in splitTagStyles) {
			if (k.startsWith('@')) continue;
			const category = formatLineReg.test(k) ? '@line' : this.#textStyleTags.includes(k) ? '@text' : '';
			if (category && tagStyles[category]) {
				splitTagStyles[k] += (splitTagStyles[k] ? '|' : '') + tagStyles[category];
			}
		}

		for (const k in splitTagStyles) {
			splitTagStyles[k] = new RegExp(`\\s*[^-a-zA-Z](${splitTagStyles[k]})\\s*:[^;]+(?!;)*`, 'gi');
		}

		const stylesMap = new Map();
		for (const key in splitTagStyles) {
			stylesMap.set(new RegExp(`^(${key})$`), splitTagStyles[key]);
		}
		this.#cleanStyleTagKeyRegExp = new RegExp(`^(${Object.keys(splitTagStyles).join('|')})$`, 'i');
		this.#cleanStyleRegExpMap = stylesMap;

		this.#brLineBlockRegExp = new RegExp(
			`<(${options.get('formatBrLine').str})(\\s[^>]*)?>([\\s\\S]*?)<\\/\\1\\s*>`,
			'gi',
		);

		// font size unit
		this.#fontSizeUnitRegExp = new RegExp('\\d+(' + options.get('fontSizeUnits').join('|') + ')$', 'i');

		// extra tags
		const allowedExtraTags = options.get('_allowedExtraTag');
		const disallowedExtraTags = options.get('_disallowedExtraTag') || '(?!)';
		this.#disallowedTagsRegExp = new RegExp(
			`<(${disallowedExtraTags})[^>]*>([\\s\\S]*?)<\\/\\1>|<(${disallowedExtraTags})[^>]*\\/?>`,
			'gi',
		);
		this.#disallowedTagNameRegExp = new RegExp(`^(${disallowedExtraTags})$`, 'i');
		this.#allowedTagNameRegExp = new RegExp(`^(${allowedExtraTags})$`, 'i');

		// empty default line probe
		this.#emptyLineRegExp = new RegExp(
			`<${options.get('defaultLine')}(?:\\s[^>]*)?></${options.get('defaultLine')}>`,
			'i',
		);

		// set disallow text nodes
		const disallowStyleNodes = Object.keys(options.get('_defaultStyleTagMap'));
		const allowStyleNodes = !options.get('elementWhitelist')
			? []
			: options
					.get('elementWhitelist')
					.split('|')
					.filter((v) => /b|i|ins|s|strike/i.test(v));
		for (let i = 0; i < allowStyleNodes.length; i++) {
			disallowStyleNodes.splice(disallowStyleNodes.indexOf(allowStyleNodes[i].toLowerCase()), 1);
		}
		this.#disallowedStyleNodesRegExp =
			disallowStyleNodes.length === 0
				? null
				: new RegExp('(<\\/?)(' + disallowStyleNodes.join('|') + ')\\b\\s*([^>^<]+)?\\s*(?=>)', 'gi');

		// whitelist
		// tags
		const defaultAttr = options.get('__defaultAttributeWhitelist');
		this.#allowHTMLComment =
			options.get('_editorElementWhitelist').includes('//') || options.get('_editorElementWhitelist') === '*';
		// html check
		this.#htmlCheckWhitelistRegExp = new RegExp(
			'^(' + GetRegList(options.get('_editorElementWhitelist').replace('|//', ''), '') + ')$',
			'i',
		);
		this.#htmlCheckBlacklistRegExp = new RegExp('^(' + (options.get('elementBlacklist') || '^') + ')$', 'i');
		// elements
		this.#elementWhitelistRegExp = converter.createElementWhitelist(
			GetRegList(options.get('_editorElementWhitelist').replace('|//', '|<!--|-->'), ''),
		);
		this.#elementBlacklistRegExp = converter.createElementBlacklist(
			options.get('elementBlacklist').replace('|//', '|<!--|-->'),
		);
		// attributes
		const regEndStr = '\\s*=\\s*(")[^"]*\\1';
		const _wAttr = options.get('attributeWhitelist');

		/** @type {Object<string, RegExp>} */
		let tagsAttr = {};
		let allAttr = '';
		if (_wAttr) {
			for (const k in _wAttr) {
				if (/^on[a-z]+$/i.test(_wAttr[k])) continue;
				if (k === '*') {
					allAttr = GetRegList(_wAttr[k], defaultAttr);
				} else {
					tagsAttr[k] = new RegExp('\\s(?:' + GetRegList(_wAttr[k], defaultAttr) + ')' + regEndStr, 'ig');
				}
			}
		}

		this.#attributeWhitelistRegExp = new RegExp(
			'\\s(?:' +
				(allAttr || defaultAttr) +
				'|' +
				REQUIRED_DATA_ATTRS +
				(options.get('v2Migration') ? V2_MIG_DATA_ATTRS : '') +
				')' +
				regEndStr,
			'ig',
		);
		this.#attributeWhitelist = tagsAttr;

		// blacklist
		const _bAttr = options.get('attributeBlacklist');
		tagsAttr = {};
		allAttr = '';
		if (_bAttr) {
			for (const k in _bAttr) {
				if (k === '*') {
					allAttr = GetRegList(_bAttr[k], '');
				} else {
					tagsAttr[k] = new RegExp('\\s(?:' + GetRegList(_bAttr[k], '') + ')' + regEndStr, 'ig');
				}
			}
		}

		this.#attributeBlacklistRegExp = new RegExp('\\s(?:' + (allAttr || '^') + ')' + regEndStr, 'ig');
		this.#attributeBlacklist = tagsAttr;

		// autoStyleify
		this.__resetAutoStyleify(options.get('autoStyleify'));
	}

	/**
	 * @description Filters an HTML string based on allowed and disallowed tags, with optional custom validation.
	 * - Removes blacklisted tags and keeps only whitelisted tags.
	 * - Allows custom validation functions to replace, modify, or remove elements.
	 * @param {string} html - The HTML string to be filtered.
	 * @param {Object} params - Filtering parameters.
	 * @param {string} [params.tagWhitelist] - Allowed tags, specified as a string with tags separated by `'|'`. (e.g. `"div|p|span"`).
	 * @param {string} [params.tagBlacklist] - Disallowed tags, specified as a string with tags separated by `'|'`. (e.g. `"script|iframe"`).
	 * @param {(node: *) => Node | string | null} [params.validate] - Function to validate and modify individual nodes.
	 *   - Return `null` to remove the node.
	 *   - Return a `Node` to replace the current node.
	 *   - Return a `string` to replace the node's `outerHTML`.
	 * @param {boolean} [params.validateAll] - Whether to apply validation to all nodes.
	 * @returns {string} - The filtered HTML string.
	 * @example
	 * // Remove script and iframe tags using blacklist
	 * const filtered = editor.html.filter('<div>Content<script>alert("xss")</script></div>', {
	 *   tagBlacklist: 'script|iframe'
	 * });
	 *
	 * // Keep only specific tags using whitelist
	 * const filtered = editor.html.filter('<div><span>Text</span><img src="x"></div>', {
	 *   tagWhitelist: 'div|span'
	 * });
	 *
	 * // Custom validation to modify nodes
	 * const filtered = editor.html.filter('<div class="test"><a href="#">Link</a></div>', {
	 *   validate: (node) => {
	 *     if (node.tagName === 'A') {
	 *       node.setAttribute('target', '_blank');
	 *       return node;
	 *     }
	 *   }
	 * });
	 */
	filter(html, { tagWhitelist, tagBlacklist, validate, validateAll }) {
		if (tagWhitelist) {
			html = html.replace(converter.createElementWhitelist(tagWhitelist), '');
		}
		if (tagBlacklist) {
			html = html.replace(converter.createElementBlacklist(tagBlacklist), '');
		}
		if (validate) {
			const parseDocument = new DOMParser().parseFromString(html, 'text/html');
			parseDocument.body.querySelectorAll('*').forEach((node) => {
				if (validateAll || (!node.closest('.se-component') && !node.closest('.se-flex-component'))) {
					const result = validate(node);
					if (result === null) {
						node.remove();
					} else if (this.#instanceCheck.isNode(result)) {
						node.replaceWith(result);
					} else if (typeof result === 'string') {
						node.outerHTML = result;
					}
				}
			});
			html = parseDocument.body.innerHTML;
		}

		return html;
	}

	/**
	 * @description Cleans and compresses HTML code to suit the editor format.
	 * @param {string} html HTML string to clean and compress
	 * @param {Object} [options] Cleaning options
	 * @param {boolean} [options.forceFormat=false] If `true`, wraps text nodes without a format node in the format tag.
	 * @param {?(string|RegExp)} [options.whitelist] Regular expression of allowed tags.
	 * Create RegExp object using `helper.converter.createElementWhitelist` method.
	 * @param {?(string|RegExp)} [options.blacklist] Regular expression of disallowed tags.
	 * Create RegExp object using `helper.converter.createElementBlacklist` method.
	 * @param {boolean} [options._freeCodeViewMode=false] If `true`, the free code view mode is enabled.
	 * @returns {string} Cleaned and compressed HTML string
	 * @example
	 * // Basic cleaning
	 * const cleaned = editor.html.clean('<div>  <p>Hello</p>  </div>');
	 *
	 * // Clean with format wrapping
	 * const cleaned = editor.html.clean('Plain text content', { forceFormat: true });
	 *
	 * // Clean with blacklist to remove specific tags
	 * const cleaned = editor.html.clean('<div><script>alert(1)</script>Content</div>', {
	 *   blacklist: 'script|style'
	 * });
	 */
	clean(html, { forceFormat, whitelist, blacklist, _freeCodeViewMode } = {}) {
		const { tagFilter, formatFilter, classFilter, textStyleTagFilter, attrFilter, styleFilter } =
			this.#options.get('strictMode');
		let cleanData = '';

		html = this.compress(html);
		html = this.#removeDisallowedExtraTags(html);

		if (tagFilter) {
			html = this.#deleteDisallowedTags(html, this.#elementWhitelistRegExp, this.#elementBlacklistRegExp).replace(
				/<br\/?>$/i,
				'',
			);
		}

		if (this.#autoStyleify) {
			const domParser = new DOMParser().parseFromString(html, 'text/html');
			dom.query.getListChildNodes(domParser.body, converter.spanToStyleNode.bind(null, this.#autoStyleify), null);
			html = domParser.body.innerHTML;
		}

		html = html.replace(/(<[a-zA-Z0-9-]+)[^>]*(?=>)/g, this.#CleanElements.bind(this, attrFilter, styleFilter));

		// get dom tree
		const domParser = _d.createRange().createContextualFragment(html);

		if (tagFilter) {
			try {
				this.#consistencyCheckOfHTML(
					domParser,
					this.#htmlCheckWhitelistRegExp,
					this.#htmlCheckBlacklistRegExp,
					tagFilter,
					formatFilter,
					classFilter,
					_freeCodeViewMode,
				);
			} catch (error) {
				console.warn('[SUNEDITOR.html.clean.fail]', error.message);
			}
		}

		// iframe placeholder parsing
		const iframePlaceholders = domParser.querySelectorAll('[data-se-iframe-holder]');
		for (let i = 0, len = iframePlaceholders.length; i < len; i++) {
			const iframe = this.#rebuildIframePlaceholder(iframePlaceholders[i], attrFilter, styleFilter);
			if (iframe) iframePlaceholders[i].replaceWith(iframe);
			else dom.utils.removeItem(iframePlaceholders[i]);
		}

		this.#$.pluginManager.applyRetainFormat(domParser);

		if (formatFilter) {
			let domTree = domParser.childNodes;
			forceFormat ||= this.#isFormatData(domTree);
			if (forceFormat) domTree = this.#editFormat(domParser).childNodes;

			for (let i = 0, len = domTree.length, t; i < len; i++) {
				t = domTree[i];
				if (this.#allowedTagNameRegExp.test(t.nodeName)) {
					cleanData += /** @type {HTMLElement} */ (t).outerHTML;
					continue;
				}
				cleanData += this.#makeLine(t, forceFormat);
			}
		}

		// set clean data
		cleanData ||= html;

		// whitelist, blacklist
		if (tagFilter) {
			if (whitelist)
				cleanData = cleanData.replace(
					typeof whitelist === 'string' ? converter.createElementWhitelist(whitelist) : whitelist,
					'',
				);
			if (blacklist)
				cleanData = cleanData.replace(
					typeof blacklist === 'string' ? converter.createElementBlacklist(blacklist) : blacklist,
					'',
				);
		}

		if (textStyleTagFilter) {
			cleanData = this.#styleNodeConvertor(cleanData);
		}

		if (!_freeCodeViewMode && cleanData.includes(unicode.zeroWidthSpace)) {
			cleanData = cleanData.replace(ZWS_RUN_REGEXP, (m, offset, str) => {
				const boundedStart = offset === 0 || str[offset - 1] === '>';
				const boundedEnd = offset + m.length === str.length || str[offset + m.length] === '<';
				return boundedStart && boundedEnd ? m : '';
			});
		}

		if (formatFilter && !_freeCodeViewMode) cleanData = this.#dropEmptyLines(cleanData);

		return cleanData;
	}

	/**
	 * @description Inserts an (HTML element / HTML string / plain string) at the selection range.
	 * - If `frameOptions.get('charCounter_max')` is exceeded when `html` is added, `null` is returned without addition.
	 * @param {Node|string} html HTML Element or HTML string or plain string
	 * @param {Object} [options] Options
	 * @param {boolean} [options.selectInserted=false] If `true`, selects the range of the inserted node.
	 * @param {boolean} [options.skipCharCount=false] If `true`, inserts even if `frameOptions.get('charCounter_max')` is exceeded.
	 * @param {boolean} [options.skipCleaning=false] If `true`, inserts the HTML string without refining it with `html.clean`.
	 * @returns {HTMLElement|null} The inserted element or `null` if insertion failed
	 * @example
	 * // Insert HTML string at cursor
	 * editor.html.insert('<strong>Bold text</strong>');
	 *
	 * // Insert and select the inserted content
	 * editor.html.insert('<p>New paragraph</p>', { selectInserted: true });
	 *
	 * // Insert raw HTML without cleaning
	 * editor.html.insert('<div class="custom">Content</div>', { skipCleaning: true });
	 */
	insert(html, { selectInserted, skipCharCount, skipCleaning } = {}) {
		if (!this.#frameContext.get('wysiwyg').contains(this.#$.selection.get().focusNode))
			this.#$.focusManager.focus();

		this.remove();
		this.#$.focusManager.focus();

		let focusNode = null;
		if (typeof html === 'string') {
			if (!skipCleaning) html = this.clean(html, { forceFormat: false, whitelist: null, blacklist: null });
			try {
				if (dom.check.isListCell(this.#$.format.getLine(this.#$.selection.getNode(), null))) {
					const domParser = _d.createRange().createContextualFragment(html);
					const domTree = domParser.childNodes;
					if (this.#isFormatData(domTree)) html = this.#convertListCell(domTree);
				}

				const domParser = _d.createRange().createContextualFragment(html);
				const domTree = domParser.childNodes;

				if (!skipCharCount) {
					const type =
						this.#frameOptions.get('charCounter_type') === 'byte-html' ? 'outerHTML' : 'textContent';
					let checkHTML = '';
					for (let i = 0, len = domTree.length; i < len; i++) {
						checkHTML += domTree[i][type];
					}
					if (!this.#$.char.check(checkHTML)) return;
				}

				let c, a, t, prev, firstCon;
				while ((c = domTree[0])) {
					if (prev?.nodeType === 3 && a?.nodeType === 1 && dom.check.isBreak(c)) {
						prev = c;
						dom.utils.removeItem(c);
						continue;
					}
					t = this.insertNode(c, { afterNode: a, skipCharCount: true });
					a = t.container || t;
					firstCon ||= t;
					prev = c;
				}

				if (prev?.nodeType === 3 && a?.nodeType === 1) a = prev;
				const offset = a.nodeType === 3 ? t.endOffset || a.textContent.length : a.childNodes.length;
				focusNode = a;

				if (selectInserted) {
					this.#$.selection.setRange(firstCon.container || firstCon, firstCon.startOffset || 0, a, offset);
				} else if (!this.#$.component.is(a)) {
					this.#$.selection.setRange(a, offset, a, offset);
				}
			} catch (error) {
				if (this.#frameContext.get('isReadOnly') || this.#frameContext.get('isDisabled')) return;
				throw Error(`[SUNEDITOR.html.insert.error] ${error.message}`);
			}
		} else {
			if (this.#$.component.is(html)) {
				this.#$.component.insert(html, { skipCharCount, insertBehavior: 'none' });
			} else {
				let afterNode = null;
				if (this.#$.format.isLine(html) || dom.check.isMedia(html)) {
					afterNode = this.#$.format.getLine(this.#$.selection.getNode(), null);
				}
				this.insertNode(html, { afterNode, skipCharCount });
			}
		}

		// focus
		this.#store.set('_lastSelectionNode', null);

		if (focusNode) {
			const children = dom.query.getListChildNodes(focusNode, null, null);
			if (children.length > 0) {
				focusNode = children.at(-1);
				const offset = focusNode?.nodeType === 3 ? focusNode.textContent.length : 1;
				this.#$.selection.setRange(focusNode, offset, focusNode, offset);
			} else {
				this.#$.focusManager.focus();
			}
		} else {
			this.#$.focusManager.focus();
		}

		this.#$.history.push(false);
	}

	/**
	 * @description Delete selected node and insert argument value node and return.
	 * - If the `afterNode` exists, it is inserted after the `afterNode`
	 * - Inserting a text node merges with both text nodes on both sides and returns a new `{ container, startOffset, endOffset }`.
	 * @param {Node} oNode Node to be inserted
	 * @param {Object} [options] Options
	 * @param {Node} [options.afterNode=null] If the node exists, it is inserted after the node
	 * @param {boolean} [options.skipCharCount=null] If `true`, it will be inserted even if `frameOptions.get('charCounter_max')` is exceeded.
	 * @returns {Object|Node|null}
	 * @example
	 * // Insert node at current selection
	 * const strongNode = document.createElement('strong');
	 * strongNode.textContent = 'Bold';
	 * editor.html.insertNode(strongNode);
	 *
	 * // Insert node after a specific element
	 * const paragraph = editor.html.getNode();
	 * const newSpan = document.createElement('span');
	 * editor.html.insertNode(newSpan, { afterNode: paragraph });
	 *
	 * // Insert bypassing character count limit
	 * editor.html.insertNode(largeContentNode, { skipCharCount: true });
	 */
	insertNode(oNode, { afterNode, skipCharCount } = {}) {
		let result = null;
		if (this.#frameContext.get('isReadOnly') || (!skipCharCount && !this.#$.char.check(oNode))) {
			return result;
		}

		let fNode = null;
		let range = null;

		if (afterNode) {
			const afterNewLine =
				this.#$.format.isLine(afterNode) || this.#$.format.isBlock(afterNode) || this.#$.component.is(afterNode)
					? this.#$.format.addLine(afterNode, null)
					: afterNode;
			range = this.#$.selection.setRange(afterNewLine, 1, afterNewLine, 1);
		} else {
			range = this.#$.selection.getRange();
		}

		let line = dom.check.isListCell(range.commonAncestorContainer)
			? range.commonAncestorContainer
			: this.#$.format.getLine(this.#$.selection.getNode(), null);
		let insertListCell = dom.check.isListCell(line) && (dom.check.isListCell(oNode) || dom.check.isList(oNode));

		let parentNode,
			originAfter,
			tempAfterNode,
			tempParentNode = null;
		const freeFormat = this.#$.format.isBrLine(line);
		const isFormats =
			this.#$.format.isLine(oNode) || this.#$.format.isBlock(oNode) || this.#$.component.isBasic(oNode);

		if (insertListCell) {
			tempAfterNode = afterNode || dom.check.isList(oNode) ? line.lastChild : line.nextElementSibling;
			tempParentNode = dom.check.isList(oNode) ? line : (tempAfterNode || line).parentNode;
		}

		if (!afterNode && (isFormats || this.#$.component.isBasic(oNode) || dom.check.isMedia(oNode))) {
			const isEdge = dom.check.isEdgePoint(range.endContainer, range.endOffset, 'end');
			const r = this.remove();
			const container = r.container;
			const prevContainer = container === r.prevContainer && range.collapsed ? null : r.prevContainer;

			if (insertListCell && prevContainer) {
				tempParentNode = prevContainer.nodeType === 3 ? prevContainer.parentNode : prevContainer;
				if (tempParentNode.contains(container)) {
					let sameParent = true;
					tempAfterNode = container;
					while (tempAfterNode.parentNode && tempAfterNode.parentNode !== tempParentNode) {
						tempAfterNode = tempAfterNode.parentNode;
						sameParent = false;
					}
					if (sameParent && container === prevContainer) tempAfterNode = tempAfterNode.nextSibling;
				} else {
					tempAfterNode = null;
				}
			} else if (insertListCell && dom.check.isListCell(container) && !line.parentElement) {
				line = dom.utils.createElement('LI');
				tempParentNode.appendChild(line);
				container.appendChild(tempParentNode);
				tempAfterNode = null;
			} else if (container.nodeType === 3 || dom.check.isBreak(container) || insertListCell) {
				const depthFormat = dom.query.getParentElement(container, (current) => {
					return this.#$.format.isBlock(current) || dom.check.isListCell(current);
				});
				afterNode = this.#$.nodeTransform.split(
					container,
					r.offset,
					!depthFormat ? 0 : dom.query.getNodeDepth(depthFormat) + 1,
				);
				if (!afterNode) {
					if (!dom.check.isListCell(line)) {
						tempAfterNode = afterNode = line;
					}
				} else if (insertListCell) {
					if (line.contains(container)) {
						const subList = dom.check.isList(line.lastElementChild);
						let newCell = null;
						if (!isEdge) {
							newCell = line.cloneNode(false);
							newCell.appendChild(
								afterNode.textContent.trim()
									? afterNode
									: dom.utils.createTextNode(unicode.zeroWidthSpace),
							);
						}
						if (subList) {
							if (!newCell) {
								newCell = line.cloneNode(false);
								newCell.appendChild(dom.utils.createTextNode(unicode.zeroWidthSpace));
							}
							newCell.appendChild(line.lastElementChild);
						}
						if (newCell) {
							line.parentNode.insertBefore(newCell, line.nextElementSibling);
							tempAfterNode = afterNode = newCell;
						}
					}
				} else {
					afterNode = afterNode.previousSibling;
				}
			}
		}

		range =
			!afterNode && !isFormats
				? this.#$.selection.getRangeAndAddLine(this.#$.selection.getRange(), null)
				: this.#$.selection.getRange();
		const commonCon = range.commonAncestorContainer;
		const startOff = range.startOffset;
		const endOff = range.endOffset;
		const formatRange = range.startContainer === commonCon && this.#$.format.isLine(commonCon);
		const startCon = formatRange
			? commonCon.childNodes[startOff] || commonCon.childNodes[0] || range.startContainer
			: range.startContainer;
		const endCon = formatRange
			? commonCon.childNodes[endOff] ||
				commonCon.childNodes[commonCon.childNodes.length - 1] ||
				range.endContainer
			: range.endContainer;

		if (!insertListCell) {
			if (!afterNode) {
				parentNode = startCon;
				if (startCon.nodeType === 3) {
					parentNode = startCon.parentNode;
				}

				/** No Select range node */
				if (range.collapsed) {
					if (commonCon.nodeType === 3) {
						if (commonCon.textContent.length > endOff)
							afterNode = /** @type {Text} */ (commonCon).splitText(endOff);
						else afterNode = commonCon.nextSibling;
					} else {
						if (!dom.check.isBreak(parentNode)) {
							const c = parentNode.childNodes[startOff];
							const focusNode =
								c?.nodeType === 3 && dom.check.isZeroWidth(c) && dom.check.isBreak(c.nextSibling)
									? c.nextSibling
									: c;
							if (focusNode) {
								if (!focusNode.nextSibling && dom.check.isBreak(focusNode)) {
									parentNode.removeChild(focusNode);
									afterNode = null;
								} else {
									afterNode =
										dom.check.isBreak(focusNode) && !dom.check.isBreak(oNode)
											? focusNode
											: focusNode.nextSibling;
								}
							} else {
								afterNode = null;
							}
						} else {
							afterNode = parentNode;
							parentNode = parentNode.parentNode;
						}
					}
				} else {
					/** Select range nodes */
					const isSameContainer = startCon === endCon;

					if (isSameContainer) {
						if (dom.check.isEdgePoint(endCon, endOff)) afterNode = endCon.nextSibling;
						else afterNode = /** @type {Text} */ (endCon).splitText(endOff);

						let removeNode = startCon;
						if (!dom.check.isEdgePoint(startCon, startOff))
							removeNode = /** @type {Text} */ (startCon).splitText(startOff);

						parentNode.removeChild(removeNode);
						if (parentNode.childNodes.length === 0 && isFormats) {
							/** @type {HTMLElement} */ (parentNode).innerHTML = '<br>';
						}
					} else {
						const removedTag = this.remove();
						const container = removedTag.container;
						const prevContainer = removedTag.prevContainer;

						if (container?.childNodes.length === 0 && isFormats) {
							if (this.#$.format.isLine(container)) {
								container.innerHTML = '<br>';
							} else if (this.#$.format.isBlock(container)) {
								container.innerHTML =
									'<' +
									this.#options.get('defaultLine') +
									'><br></' +
									this.#options.get('defaultLine') +
									'>';
							}
						}

						if (dom.check.isListCell(container) && oNode.nodeType === 3) {
							parentNode = container;
							afterNode = null;
						} else if (!isFormats && prevContainer) {
							parentNode = prevContainer.nodeType === 3 ? prevContainer.parentNode : prevContainer;
							if (parentNode.contains(container)) {
								let sameParent = true;
								afterNode = container;
								while (afterNode.parentNode && afterNode.parentNode !== parentNode) {
									afterNode = afterNode.parentNode;
									sameParent = false;
								}
								if (sameParent && container === prevContainer) afterNode = afterNode.nextSibling;
							} else {
								afterNode = null;
							}
						} else if (dom.check.isWysiwygFrame(container) && !this.#$.format.isLine(oNode)) {
							parentNode = container.appendChild(
								dom.utils.createElement(this.#options.get('defaultLine')),
							);
							afterNode = null;
						} else {
							afterNode = isFormats
								? endCon
								: container === prevContainer
									? container.nextSibling
									: container;
							parentNode = !afterNode || !afterNode.parentNode ? commonCon : afterNode.parentNode;
						}

						while (afterNode && !this.#$.format.isLine(afterNode) && afterNode.parentNode !== commonCon) {
							afterNode = afterNode.parentNode;
						}
					}
				}
			} else {
				// has afterNode
				parentNode = afterNode.parentNode;
				afterNode = afterNode.nextSibling;
				originAfter = true;
			}
		}

		try {
			// set node
			const wysiwyg = this.#frameContext.get('wysiwyg');
			if (!insertListCell) {
				if (dom.check.isWysiwygFrame(afterNode) || parentNode === wysiwyg.parentNode) {
					parentNode = wysiwyg;
					afterNode = null;
				}

				if (
					this.#$.format.isLine(oNode) ||
					this.#$.format.isBlock(oNode) ||
					(!dom.check.isListCell(parentNode) && this.#$.component.isBasic(oNode))
				) {
					const oldParent = parentNode;
					if (dom.check.isListCell(afterNode)) {
						parentNode = afterNode.previousElementSibling || afterNode;
					} else if (!originAfter && !afterNode) {
						const r = this.remove();
						const container =
							r.container.nodeType === 3
								? dom.check.isListCell(this.#$.format.getLine(r.container, null))
									? r.container
									: this.#$.format.getLine(r.container, null) || r.container.parentNode
								: r.container;
						const rangeCon = dom.check.isWysiwygFrame(container) || this.#$.format.isBlock(container);
						parentNode = rangeCon ? container : container.parentNode;
						afterNode = rangeCon ? null : container.nextSibling;
					}

					if (oldParent.childNodes.length === 0 && parentNode !== oldParent) dom.utils.removeItem(oldParent);
				}

				if (
					isFormats &&
					!freeFormat &&
					!this.#$.format.isBlock(parentNode) &&
					!dom.check.isListCell(parentNode) &&
					!dom.check.isWysiwygFrame(parentNode)
				) {
					afterNode = /** @type {HTMLElement} */ (parentNode).nextElementSibling;
					parentNode = parentNode.parentNode;
				}

				if (dom.check.isWysiwygFrame(parentNode) && (oNode.nodeType === 3 || dom.check.isBreak(oNode))) {
					const formatNode = dom.utils.createElement(this.#options.get('defaultLine'), null, oNode);
					fNode = oNode;
					oNode = formatNode;
				}
			}

			// insert--
			if (insertListCell) {
				if (!tempParentNode.parentNode) {
					parentNode = wysiwyg;
					afterNode = null;
				} else {
					parentNode = tempParentNode;
					afterNode = tempAfterNode;
				}
			} else {
				afterNode = parentNode === afterNode ? parentNode.lastChild : afterNode;
			}

			if (dom.check.isListCell(oNode) && !dom.check.isList(parentNode)) {
				if (dom.check.isListCell(parentNode)) {
					afterNode = parentNode.nextElementSibling;
					parentNode = parentNode.parentNode;
				} else {
					const ul = dom.utils.createElement('ol');
					parentNode.insertBefore(ul, afterNode);
					parentNode = ul;
					afterNode = null;
				}
				insertListCell = true;
			}

			this.#checkDuplicateNode(oNode, parentNode);
			parentNode.insertBefore(oNode, afterNode);

			if (insertListCell) {
				if (dom.check.isZeroWidth(line.textContent.trim())) {
					dom.utils.removeItem(line);
					oNode = oNode.lastChild;
				} else {
					const chList = dom.utils.arrayFind(line.children, dom.check.isList);
					if (chList) {
						if (oNode !== chList) {
							oNode.appendChild(chList);
							oNode = chList.previousSibling;
						} else {
							parentNode.appendChild(oNode);
							oNode = parentNode;
						}

						if (dom.check.isZeroWidth(line.textContent.trim())) {
							dom.utils.removeItem(line);
						}
					}
				}
			}
		} catch (error) {
			parentNode.appendChild(oNode);
			console.warn('[SUNEDITOR.html.insertNode.warn]', error);
		} finally {
			if (fNode) oNode = fNode;

			const dupleNodes = /** @type {HTMLElement} */ (parentNode).querySelectorAll('[data-duple]');
			if (dupleNodes.length > 0) {
				for (let i = 0, len = dupleNodes.length, d, c, ch, parent; i < len; i++) {
					d = dupleNodes[i];
					ch = d.childNodes;
					parent = d.parentNode;

					while (ch[0]) {
						c = ch[0];
						parent.insertBefore(c, d);
					}

					if (d === oNode) oNode = c;
					dom.utils.removeItem(d);
				}
			}

			if ((this.#$.format.isLine(oNode) || this.#$.component.isBasic(oNode)) && startCon === endCon) {
				const cItem = this.#$.format.getLine(commonCon, null);
				if (cItem?.nodeType === 1 && dom.check.isEmptyLine(cItem)) {
					dom.utils.removeItem(cItem);
				}
			}

			if (
				freeFormat &&
				!dom.check.isList(oNode) &&
				(this.#$.format.isLine(oNode) || this.#$.format.isBlock(oNode))
			) {
				oNode = this.#setIntoFreeFormat(oNode);
			}

			if (!this.#$.component.isBasic(oNode)) {
				let offset = 1;
				if (oNode.nodeType === 3) {
					offset = oNode.textContent.length;
					this.#$.selection.setRange(oNode, offset, oNode, offset);
				} else if (
					!dom.check.isBreak(oNode) &&
					!dom.check.isListCell(oNode) &&
					this.#$.format.isLine(parentNode)
				) {
					let zeroWidth = null;
					if (!oNode.previousSibling || dom.check.isBreak(oNode.previousSibling)) {
						zeroWidth = dom.utils.createTextNode(unicode.zeroWidthSpace);
						oNode.parentNode.insertBefore(zeroWidth, oNode);
					}

					if (!oNode.nextSibling || dom.check.isBreak(oNode.nextSibling)) {
						zeroWidth = dom.utils.createTextNode(unicode.zeroWidthSpace);
						oNode.parentNode.insertBefore(zeroWidth, oNode.nextSibling);
					}

					if (this.#$.inline._isIgnoreNodeChange(oNode)) {
						oNode = oNode.nextSibling;
						offset = 0;
					}

					this.#$.selection.setRange(oNode, offset, oNode, offset);
				}
			}

			result = oNode;
		}

		return result;
	}

	/**
	 * @description Delete the selected range.
	 * @returns {{container: Node, offset: number, commonCon?: ?Node, prevContainer?: ?Node}}
	 * - `container`: the last element after deletion
	 * - `offset`: offset
	 * - `commonCon`: `commonAncestorContainer`
	 * - `prevContainer`: `previousElementSibling` of the deleted area
	 */
	remove() {
		this.#$.selection.resetRangeToTextNode();

		const range = this.#$.selection.getRange();
		const isStartEdge = range.startOffset === 0;
		const isEndEdge = dom.check.isEdgePoint(range.endContainer, range.endOffset, 'end');
		let prevContainer = null;
		let startPrevEl = null;
		let endNextEl = null;
		if (isStartEdge) {
			startPrevEl = this.#$.format.getLine(range.startContainer);
			prevContainer = startPrevEl ? startPrevEl.previousElementSibling : null;
			startPrevEl = startPrevEl ? prevContainer : startPrevEl;
		}
		if (isEndEdge) {
			endNextEl = this.#$.format.getLine(range.endContainer);
			endNextEl = endNextEl ? endNextEl.nextElementSibling : endNextEl;
		}

		let container,
			offset = 0;
		let startCon = range.startContainer;
		let endCon = range.endContainer;
		let startOff = range.startOffset;
		let endOff = range.endOffset;
		const commonCon = /** @type {HTMLElement} */ (
			range.commonAncestorContainer.nodeType === 3 &&
			range.commonAncestorContainer.parentNode === startCon.parentNode
				? startCon.parentNode
				: range.commonAncestorContainer
		);

		if (dom.check.isWysiwygFrame(startCon) && dom.check.isWysiwygFrame(endCon)) {
			this.set('');
			const newInitBR = this.#$.selection.getNode();
			return {
				container: newInitBR,
				offset: 0,
				commonCon,
			};
		}

		if (commonCon === startCon && commonCon === endCon) {
			if (this.#$.component.isBasic(commonCon)) {
				const compInfo = this.#$.component.get(commonCon);
				const compContainer = compInfo.container;
				const parent = compContainer.parentElement;

				const next = compContainer.nextSibling || compContainer.previousSibling;
				const nextOffset = next === compContainer.previousSibling ? next?.textContent?.length || 1 : 0;
				const parentNext = parent.nextElementSibling || parent.previousElementSibling;
				const parentNextOffset =
					parentNext === parent.previousElementSibling ? parentNext?.textContent?.length || 1 : 0;

				dom.utils.removeItem(compContainer);

				if (this.#$.format.isLine(parent)) {
					if (parent.childNodes.length === 0) {
						dom.utils.removeItem(parent);
						return {
							container: parentNext,
							offset: parentNextOffset,
							commonCon,
						};
					} else {
						return {
							container: next,
							offset: nextOffset,
							commonCon,
						};
					}
				} else {
					return {
						container: parentNext,
						offset: parentNextOffset,
						commonCon,
					};
				}
			} else {
				if (
					(commonCon.nodeType === 1 && startOff === 0 && endOff === 1) ||
					(commonCon.nodeType === 3 && startOff === 0 && endOff === commonCon.textContent.length)
				) {
					const nextEl = dom.query.getNextDeepestNode(commonCon, this.#frameContext.get('wysiwyg'));
					const prevEl = dom.query.getPreviousDeepestNode(commonCon, this.#frameContext.get('wysiwyg'));
					const line = this.#$.format.getLine(commonCon);
					dom.utils.removeItem(commonCon);

					let rEl = nextEl || prevEl;
					let rOffset = nextEl ? 0 : rEl?.nodeType === 3 ? rEl.textContent.length : 1;

					const npEl = this.#$.format.getLine(rEl) || this.#$.component.get(rEl);
					if (line !== npEl) {
						rEl = /** @type {Node} */ (npEl);
						rOffset = rOffset === 0 ? 0 : 1;
					}

					if (dom.check.isZeroWidth(line) && !line.contains(rEl)) {
						dom.utils.removeItem(line);
					}

					return {
						container: rEl,
						offset: rOffset,
						commonCon,
					};
				}

				startCon = commonCon.children[startOff];
				endCon = commonCon.children[endOff];
				startOff = endOff = 0;
			}
		}

		if (!startCon || !endCon)
			return {
				container: commonCon,
				offset: 0,
				commonCon,
			};

		if (startCon === endCon && range.collapsed) {
			if (dom.check.isZeroWidth(startCon.textContent?.substring(startOff))) {
				return {
					container: startCon,
					offset: startOff,
					prevContainer: startCon && startCon.parentNode ? startCon : null,
					commonCon,
				};
			}
		}

		let beforeNode = null;
		let afterNode = null;

		const childNodes = dom.query.getListChildNodes(commonCon, null, null);
		let startIndex = dom.utils.getArrayIndex(childNodes, startCon);
		let endIndex = dom.utils.getArrayIndex(childNodes, endCon);

		if (childNodes.length > 0 && startIndex > -1 && endIndex > -1) {
			for (let i = startIndex + 1, startNode = startCon; i >= 0; i--) {
				if (
					childNodes[i] === startNode.parentNode &&
					childNodes[i].firstChild === startNode &&
					startOff === 0
				) {
					startIndex = i;
					startNode = startNode.parentNode;
				}
			}

			for (let i = endIndex - 1, endNode = endCon; i > startIndex; i--) {
				if (childNodes[i] === endNode.parentNode && childNodes[i].nodeType === 1) {
					childNodes.splice(i, 1);
					endNode = endNode.parentNode;
					--endIndex;
				}
			}
		} else {
			if (childNodes.length === 0) {
				if (
					this.#$.format.isLine(commonCon) ||
					this.#$.format.isBlock(commonCon) ||
					dom.check.isWysiwygFrame(commonCon) ||
					dom.check.isBreak(commonCon) ||
					dom.check.isMedia(commonCon)
				) {
					return {
						container: commonCon,
						offset: 0,
						commonCon,
					};
				} else if (dom.check.isText(commonCon)) {
					return {
						container: commonCon,
						offset: endOff,
						commonCon,
					};
				}
				childNodes.push(commonCon);
				startCon = endCon = commonCon;
			} else {
				startCon = endCon = childNodes[0];
				if (dom.check.isBreak(startCon) || dom.check.isZeroWidth(startCon)) {
					return {
						container: dom.check.isMedia(commonCon) ? commonCon : startCon,
						offset: 0,
						commonCon,
					};
				}
			}

			startIndex = endIndex = 0;
		}

		const _isText = dom.check.isText;
		const _isElement = dom.check.isElement;
		const _isSingleItem = startIndex === endIndex;
		let nextFocusNodes = null;
		for (let i = startIndex; i <= endIndex; i++) {
			const item = /** @type {Text} */ (childNodes[i]);

			if (_isText(item) && (item.data === undefined || item.length === 0)) {
				nextFocusNodes = this.#nodeRemoveListItem(item, _isSingleItem);
				continue;
			}

			if (item === startCon) {
				if (_isElement(startCon)) {
					if (this.#$.component.is(startCon)) continue;
					else beforeNode = dom.utils.createTextNode(startCon.textContent);
				} else {
					const sc = /** @type {Text} */ (startCon);
					const ec = /** @type {Text} */ (endCon);
					if (item === endCon) {
						beforeNode = dom.utils.createTextNode(
							sc.substringData(0, startOff) + ec.substringData(endOff, ec.length - endOff),
						);
						offset = startOff;
					} else {
						beforeNode = dom.utils.createTextNode(sc.substringData(0, startOff));
					}
				}

				if (beforeNode.length > 0) {
					/** @type {Text} */ (startCon).data = beforeNode.data;
				} else {
					nextFocusNodes = this.#nodeRemoveListItem(startCon, _isSingleItem);
				}

				if (item === endCon) break;
				continue;
			}

			if (item === endCon) {
				if (_isText(endCon)) {
					afterNode = dom.utils.createTextNode(endCon.substringData(endOff, endCon.length - endOff));
				} else {
					if (this.#$.component.is(endCon)) continue;
					else afterNode = dom.utils.createTextNode(endCon.textContent);
				}

				if (afterNode.length > 0) {
					/** @type {Text} */ (endCon).data = afterNode.data;
				} else {
					nextFocusNodes = this.#nodeRemoveListItem(endCon, _isSingleItem);
				}

				continue;
			}

			nextFocusNodes = this.#nodeRemoveListItem(item, _isSingleItem);
		}

		const endUl = dom.query.getParentElement(endCon, 'ul');
		const startLi = dom.query.getParentElement(startCon, 'li');
		if (endUl && startLi && startLi.contains(endUl)) {
			container = endUl.previousSibling;
			offset = container.textContent.length;
		} else {
			container =
				endCon && endCon.parentNode
					? endCon
					: startCon && startCon.parentNode
						? startCon
						: range.endContainer || range.startContainer;
			if (isStartEdge || isEndEdge) {
				if (isEndEdge) {
					if (container.nodeType === 1 && container.childNodes.length === 0) {
						container.appendChild(dom.utils.createElement('BR'));
						offset = 1;
					} else {
						offset = container.textContent.length;
					}
				} else {
					offset = 0;
				}
			}
		}

		if (!this.#$.format.getLine(container) && !(startCon && startCon.parentNode)) {
			if (endNextEl) {
				container = endNextEl;
				offset = 0;
			} else if (startPrevEl) {
				container = startPrevEl;
				offset = 1;
			}
		}

		if (
			!dom.check.isWysiwygFrame(container) &&
			container.childNodes.length === 0 &&
			(container.nodeType === 1 || dom.check.isZeroWidth(container))
		) {
			const rc = this.#$.nodeTransform.removeAllParents(container, null, null);
			if (rc) container = rc.sc || rc.ec || this.#frameContext.get('wysiwyg');
		}

		if (
			!container ||
			(container.nodeType === 1 && !this.#$.format.isLine(container) && !dom.check.isBreak(container))
		) {
			container = nextFocusNodes?.sc || nextFocusNodes?.ec;
			offset = container?.nodeType === 3 ? container.textContent.length : 1;
		}

		// set range
		this.#$.selection.setRange(container, offset, container, offset);

		return {
			container,
			offset,
			prevContainer,
			commonCon: commonCon?.parentElement ? commonCon : null,
		};
	}

	/**
	 * @description Gets the current content
	 * @param {Object} [options] Options
	 * @param {boolean} [options.withFrame=false] Gets the current content with containing parent `div.sun-editor-editable` (`<div class="sun-editor-editable">{content}</div>`).
	 * Ignored for `targetOptions.get('iframe_fullPage')` is `true`.
	 * @param {boolean} [options.includeFullPage=false] Return only the content of the body without headers when the `iframe_fullPage` option is `true`
	 * @param {number|Array<number>} [options.rootKey=null] Root index
	 * @returns {string|Object<*, string>}
	 * @example
	 * const html = editor.$.html.get();
	 * const htmlWithFrame = editor.$.html.get({ withFrame: true });
	 */
	get({ withFrame, includeFullPage, rootKey } = {}) {
		if (!rootKey) rootKey = [this.#store.get('rootKey')];
		else if (!Array.isArray(rootKey)) rootKey = [rootKey];

		const prevrootKey = this.#store.get('rootKey');
		const resultValue = {};
		for (let i = 0, len = rootKey.length, r; i < len; i++) {
			this.#$.facade.changeFrameContext(rootKey[i]);

			const renderHTML = dom.utils.createElement(
				'DIV',
				null,
				this._convertToCode(this.#frameContext.get('wysiwyg'), true),
			);

			const phLines = renderHTML.querySelectorAll('.se-placeholder-line');
			for (let j = 0, jlen = phLines.length; j < jlen; j++) {
				phLines[j].classList.remove('se-placeholder-line');
				phLines[j].removeAttribute('data-se-placeholder-line');
				if (!phLines[j].getAttribute('class')) phLines[j].removeAttribute('class');
			}

			const isTableCell = dom.check.isTableCell;
			const isEmptyLine = dom.check.isEmptyLine;
			const isComponent = (el) => this.#$.component.is(el);
			const editableEls = [];
			const emptyCells = [];
			dom.query.getListChildren(
				renderHTML,
				(current) => {
					if (current.hasAttribute('contenteditable')) {
						editableEls.push(current);
					}

					const parent = current.parentElement;
					if (
						isTableCell(parent) &&
						parent.children.length <= 1 &&
						isEmptyLine(current) &&
						!isComponent(current) &&
						!dom.utils.arrayFind(current.querySelectorAll('*'), isComponent)
					) {
						emptyCells.push(parent);
					}
					return false;
				},
				null,
			);

			for (let j = 0, jlen = editableEls.length; j < jlen; j++) {
				editableEls[j].removeAttribute('contenteditable');
			}
			for (let j = 0, jlen = emptyCells.length; j < jlen; j++) {
				emptyCells[j].innerHTML = '<br>';
			}

			// output: wrap code blocks <pre class="language-xxx"> → <pre><code class="language-xxx">
			this.#wrapPreCode(renderHTML);

			const content = renderHTML.innerHTML;
			if (this.#frameOptions.get('iframe_fullPage')) {
				if (includeFullPage) {
					const attrs = dom.utils.getAttributesToString(this.#frameContext.get('_wd').body, [
						'contenteditable',
					]);
					r = `<!DOCTYPE html><html>${this.#frameContext.get('_wd').head.outerHTML}<body ${attrs}>${content}</body></html>`;
				} else {
					r = content;
				}
			} else {
				r = withFrame
					? `<div class="${this.#options.get('_editableClass') + '' + (this.#options.get('_rtl') ? ' se-rtl' : '')}">${content}</div>`
					: renderHTML.innerHTML;
			}

			resultValue[rootKey[i]] = r;
		}

		this.#$.facade.changeFrameContext(prevrootKey);
		return rootKey.length > 1 ? resultValue : resultValue[rootKey[0]];
	}

	/**
	 * @description Sets the HTML string to the editor content
	 * @param {string} html HTML string
	 * @param {Object} [options] Options
	 * @param {number|Array<number>} [options.rootKey=null] Root index
	 * @example
	 * editor.$.html.set('<p>New content</p>');
	 * editor.$.html.set(html, { rootKey: 'header' });
	 */
	set(html, { rootKey } = {}) {
		this.#$.ui.offCurrentController();
		this.#$.selection.removeRange();
		const convertValue =
			html === null || html === undefined
				? ''
				: this.clean(html, { forceFormat: true, whitelist: null, blacklist: null });

		if (!rootKey) rootKey = [this.#store.get('rootKey')];
		else if (!Array.isArray(rootKey)) rootKey = [rootKey];

		for (let i = 0; i < rootKey.length; i++) {
			this.#$.facade.changeFrameContext(rootKey[i]);

			if (this.#frameContext.get('isMarkdownView')) {
				const json = converter.htmlToJson(convertValue);
				this.#frameContext.get('markdown').value = markdown.jsonToMarkdown(json);
			} else if (!this.#frameContext.get('isCodeView')) {
				this.#frameContext.get('wysiwyg').innerHTML = convertValue;
				this.#$.pluginManager.resetFileInfo();
				this.#$.history.push(false, rootKey[i]);
			} else {
				const value = this._convertToCode(convertValue, false);
				this.#$.viewer._setCodeView(value);
			}
		}
	}

	/**
	 * @description Add content to the end of content.
	 * @param {string} html Content to Input
	 * @param {Object} [options] Options
	 * @param {number|Array<number>} [options.rootKey=null] Root index
	 */
	add(html, { rootKey } = {}) {
		this.#$.ui.offCurrentController();

		if (!rootKey) rootKey = [this.#store.get('rootKey')];
		else if (!Array.isArray(rootKey)) rootKey = [rootKey];

		for (let i = 0; i < rootKey.length; i++) {
			this.#$.facade.changeFrameContext(rootKey[i]);
			const convertValue = this.clean(html, { forceFormat: true, whitelist: null, blacklist: null });

			if (this.#frameContext.get('isMarkdownView')) {
				const json = converter.htmlToJson(convertValue);
				this.#frameContext.get('markdown').value += '\n' + markdown.jsonToMarkdown(json);
			} else if (!this.#frameContext.get('isCodeView')) {
				const temp = dom.utils.createElement('DIV', null, convertValue);
				const children = Array.from(temp.children);
				for (let j = 0, jLen = children.length; j < jLen; j++) {
					this.#frameContext.get('wysiwyg').appendChild(children[j]);
				}
				this.#$.history.push(false, rootKey[i]);
				this.#$.selection.scrollTo(children.at(-1));
			} else {
				this.#$.viewer._setCodeView(
					this.#$.viewer._getCodeView() + '\n' + this._convertToCode(convertValue, false),
				);
			}
		}
	}

	/**
	 * @description Gets the current content to JSON data
	 * - Text content keeps its whitespace as-is (see @link converter.htmlToJson).
	 * @param {Object} [options] Options
	 * @param {boolean} [options.withFrame=false] Gets the current content with containing parent `div.sun-editor-editable` (`<div class="sun-editor-editable">{content}</div>`).
	 * @param {number|Array<number>} [options.rootKey=null] Root index
	 * @returns {Object<string, *>} JSON data
	 * @example
	 * const json = editor.$.html.getJson();
	 * const jsonWithFrame = editor.$.html.getJson({ withFrame: true });
	 */
	getJson({ withFrame, rootKey } = {}) {
		return converter.htmlToJson(this.get({ withFrame, rootKey }));
	}

	/**
	 * @description Sets the JSON data to the editor content
	 * (see @link converter.jsonToHtml)
	 * @param {Object<string, *>} jsdonData HTML string
	 * @param {Object} [options] Options
	 * @param {number|Array<number>} [options.rootKey=null] Root index
	 * @example
	 * const html = editor.$.html.setJson({
	 *   type: 'element', tag: 'p', attributes: { class: 'txt' },
	 *   children: [{ type: 'text', content: 'Hello' }],
	 * });
	 * // '<p class="txt">Hello</p>'
	 */
	setJson(jsdonData, { rootKey } = {}) {
		this.set(converter.jsonToHtml(jsdonData), { rootKey });
	}

	/**
	 * @description Call `clipboard.write` to copy the contents and display a success/failure toast message.
	 * @param {Node|Element|Text|string} content Content to be copied to the clipboard
	 * @returns {Promise<boolean>} Success or failure
	 */
	async copy(content) {
		try {
			if (typeof content !== 'string' && !dom.check.isElement(content) && !dom.check.isText(content))
				return false;

			if ((await clipboard.write(content)) === false) {
				this.#$.ui.showToast(
					this.#$.lang.message_copy_fail,
					this.#options.get('toastMessageTime').copy,
					'error',
				);
				return false;
			}
			this.#$.ui.showToast(this.#$.lang.message_copy_success, this.#options.get('toastMessageTime').copy);
			return true;
		} catch (err) {
			console.error('[SUNEDITOR.html.copy.fail] :', err);
			this.#$.ui.showToast(this.#$.lang.message_copy_fail, this.#options.get('toastMessageTime').copy, 'error');
			return false;
		}
	}

	/**
	 * @description Sets the content of the iframe's head tag and body tag when using the `iframe` or `iframe_fullPage` option.
	 * @param {{head: string, body: string}} ctx { head: HTML string, body: HTML string}
	 * @param {Object} [options] Options
	 * @param {number|Array<number>} [options.rootKey=null] Root index
	 */
	setFullPage(ctx, { rootKey } = {}) {
		if (!this.#frameOptions.get('iframe')) return false;

		if (!rootKey) rootKey = [this.#store.get('rootKey')];
		else if (!Array.isArray(rootKey)) rootKey = [rootKey];

		for (let i = 0; i < rootKey.length; i++) {
			this.#$.facade.changeFrameContext(rootKey[i]);
			if (ctx.head) this.#frameContext.get('_wd').head.innerHTML = this.#removeDisallowedExtraTags(ctx.head);
			if (ctx.body)
				this.#frameContext.get('_wd').body.innerHTML = this.clean(ctx.body, {
					forceFormat: true,
					whitelist: null,
					blacklist: null,
				});
			this.#$.pluginManager.resetFileInfo();
		}
	}

	/**
	 * @description HTML code compression
	 * @param {string} html HTML string
	 * @returns {string} HTML string
	 */
	compress(html) {
		let result = '';
		let last = 0;
		for (const m of html.matchAll(this.#brLineBlockRegExp)) {
			const [block, tag, attrs = '', body] = m;
			result += this.#compressText(html.slice(last, m.index));
			result += `<${tag}${attrs}>${body.replace(/^\r?\n/, '').replace(/(<br\s*\/?>)?\r?\n/gi, '<br>')}</${tag}>`;
			last = m.index + block.length;
		}
		return (result + this.#compressText(html.slice(last))).trim();
	}

	/**
	 * @internal
	 * @description construct wysiwyg area element to html string
	 * @param {Node|string} html WYSIWYG element (this.#frameContext.get('wysiwyg')) or HTML string.
	 * @param {boolean} comp If `true`, does not line break and indentation of tags.
	 * @returns {string}
	 */
	_convertToCode(html, comp) {
		let returnHTML = '';
		const wRegExp = RegExp;
		const brReg = new wRegExp(
			'^(BLOCKQUOTE|PRE|TABLE|THEAD|TBODY|TR|TH|TD|OL|UL|IMG|IFRAME|VIDEO|AUDIO|FIGURE|FIGCAPTION|HR|BR|CANVAS|SELECT)$',
			'i',
		);
		const wDoc = typeof html === 'string' ? _d.createRange().createContextualFragment(html) : html;
		const isFormat = (current) => {
			return this.#$.format.isLine(current) || this.#$.component.is(current);
		};
		const brChar = comp ? '' : '\n';
		const brLineReg = this.#options.get('formatBrLine').reg;

		const codeSize = comp ? 0 : this.#store.get('codeIndentSize') * 1;
		const indentSize = codeSize > 0 ? new Array(codeSize + 1).join(' ') : '';

		(function recursionFunc(element, indent, inBrLine) {
			const children = element?.childNodes;
			if (!children) return;

			const elementRegTest = brReg.test(element.nodeName);
			const elementIndent = elementRegTest && !inBrLine ? indent : '';

			for (
				let i = 0, len = children.length, node, br, lineBR, nodeRegTest, nodeBrLine, tag, tagIndent;
				i < len;
				i++
			) {
				node = children[i];
				nodeRegTest = brReg.test(node.nodeName);
				br = (inBrLine ? /^BR$/i.test(node.nodeName) : nodeRegTest) ? brChar : '';
				lineBR =
					!inBrLine && isFormat(node) && !elementRegTest && !/^(TH|TD)$/i.test(element.nodeName)
						? brChar
						: '';

				if (node.nodeType === 8) {
					returnHTML += '\n<!-- ' + node.textContent.trim() + ' -->' + br;
					continue;
				}
				if (node.nodeType === 3) {
					if (!dom.check.isList(node.parentElement))
						returnHTML += converter.htmlToEntity(
							/^\n+$/.test(/** @type {Text} */ (node).data) ? '' : /** @type {Text} */ (node).data,
						);
					continue;
				}
				if (node.childNodes.length === 0) {
					returnHTML +=
						(!inBrLine && /^HR$/i.test(node.nodeName) ? brChar : '') +
						elementIndent +
						/** @type {HTMLElement} */ (node).outerHTML +
						br;
					continue;
				}

				if (!(/** @type {HTMLElement} */ (node).outerHTML)) {
					returnHTML += new XMLSerializer().serializeToString(node);
				} else {
					tag = node.nodeName.toLowerCase();
					nodeBrLine = inBrLine || brLineReg.test(node.nodeName);
					tagIndent = !inBrLine && (elementIndent || nodeRegTest) ? indent : '';
					returnHTML +=
						(lineBR || (elementRegTest ? '' : br)) +
						tagIndent +
						/** @type {HTMLElement} */ (node).outerHTML.match(wRegExp('<' + tag + '[^>]*>', 'i'))[0] +
						br;
					recursionFunc(node, indent + indentSize + '', nodeBrLine);
					returnHTML +=
						(!nodeBrLine && /\n$/.test(returnHTML) ? tagIndent : '') +
						'</' +
						tag +
						'>' +
						(!inBrLine && (lineBR || br || elementRegTest || /^(TH|TD)$/i.test(node.nodeName))
							? brChar
							: '');
				}
			}
		})(wDoc, '', false);

		return returnHTML.trim() + brChar;
	}

	/**
	 * @description Checks whether the given list item node should be removed and handles necessary clean-up.
	 * @param {Node} item The list item node to be checked.
	 * @param {boolean} isSingleItem Single item
	 * @returns {{sc:Node, ec:Node}|null} An object containing the start and end containers if any transformations were made, otherwise `null`.
	 */
	#nodeRemoveListItem(item, isSingleItem) {
		const line = this.#$.format.getLine(item, null);
		dom.utils.removeItem(item);

		if (!dom.check.isListCell(line) || isSingleItem) return;

		const result = this.#$.nodeTransform.removeAllParents(line, null, null);

		if (dom.check.isList(line?.firstChild)) {
			line.insertBefore(dom.utils.createTextNode(unicode.zeroWidthSpace), line.firstChild);
		}

		return result ? { sc: result.sc, ec: result.ec } : null;
	}

	/**
	 * @description Recursive function when used to place a node in `BrLine` in `html.insertNode`
	 * @param {Node} oNode Node to be inserted
	 * @returns {Node} `oNode`
	 */
	#setIntoFreeFormat(oNode) {
		const parentNode = oNode.parentNode;
		let oNodeChildren, lastONode;

		while (this.#$.format.isLine(oNode) || this.#$.format.isBlock(oNode)) {
			oNodeChildren = oNode.childNodes;
			lastONode = null;

			while (oNodeChildren[0]) {
				lastONode = oNodeChildren[0];
				if (this.#$.format.isLine(lastONode) || this.#$.format.isBlock(lastONode)) {
					this.#setIntoFreeFormat(lastONode);
					if (!oNode.parentNode) break;
					oNodeChildren = oNode.childNodes;
					continue;
				}

				parentNode.insertBefore(lastONode, oNode);
			}

			if (oNode.childNodes.length === 0) dom.utils.removeItem(oNode);
			oNode = dom.utils.createElement('BR');
			parentNode.insertBefore(oNode, lastONode.nextSibling);
		}

		return oNode;
	}

	/**
	 * @description Returns HTML string according to tag type and configuration `isExcludeFormat`.
	 * @param {Node} node Node
	 * @param {boolean} forceFormat If `true`, text nodes that do not have a format node is wrapped with the format tag.
	 */
	#makeLine(node, forceFormat) {
		const defaultLine = this.#options.get('defaultLine');
		// element
		if (node.nodeType === 1) {
			if (this.#disallowedTagNameRegExp.test(node.nodeName)) return '';
			if (dom.check.isExcludeFormat(node)) return node.outerHTML;

			const ch =
				dom.query.getListChildNodes(
					node,
					(current) => {
						return (
							dom.check.isSpanWithoutAttr(current) &&
							!dom.query.getParentElement(current, dom.check.isExcludeFormat)
						);
					},
					null,
				) || [];
			for (let i = ch.length - 1, c; i >= 0; i--) {
				c = /** @type {HTMLElement} */ (ch[i]);
				c.replaceWith(...c.childNodes);
			}

			if (
				!forceFormat ||
				this.#$.format.isLine(node) ||
				this.#$.format.isBlock(node) ||
				this.#$.component.is(node) ||
				dom.check.isMedia(node) ||
				dom.check.isFigure(node) ||
				(dom.check.isAnchor(node) && dom.check.isMedia(node.firstElementChild))
			) {
				const n = /** @type {HTMLElement} */ (node);
				return dom.check.isSpanWithoutAttr(node) ? n.innerHTML : n.outerHTML;
			} else {
				const n = /** @type {HTMLElement} */ (node);
				return (
					'<' +
					defaultLine +
					'>' +
					(dom.check.isSpanWithoutAttr(node) ? n.innerHTML : n.outerHTML) +
					'</' +
					defaultLine +
					'>'
				);
			}
		}
		// text
		if (node.nodeType === 3) {
			if (!forceFormat) return converter.htmlToEntity(node.textContent);
			const textArray = node.textContent.split(/\n/g);
			let html = '';
			for (let i = 0, tLen = textArray.length, text; i < tLen; i++) {
				text = textArray[i].trim();
				if (text.length > 0)
					html += '<' + defaultLine + '>' + converter.htmlToEntity(text) + '</' + defaultLine + '>';
			}
			return html;
		}
		// comments
		if (node.nodeType === 8 && this.#allowHTMLComment) {
			return '<!--' + node.textContent.trim() + '-->';
		}

		return '';
	}

	/**
	 * @description Compresses HTML outside brLine blocks: collapses whitespace between tags and turns a line break into a space.
	 * - A line break after `<br>` (code view output) is dropped; it would only start the next line with a space.
	 * @param {string} html HTML string
	 * @returns {string} Compressed HTML string
	 */
	#compressText(html) {
		return html
			.replace(/(<br\s*\/?>)\s*\n\s*/gi, '$1')
			.replace(/>\s+</g, '> <')
			.replace(/\s*\n\s*/g, ' ');
	}

	/**
	 * @description Drops empty default lines (`<p></p>`) from a cleaned HTML string.
	 * Wrapping block-level content in a default line is invalid HTML, so the parser tears the line
	 * apart and leaves caret-less debris behind. An intentionally blank line always carries `<br>`.
	 * @param {string} html Cleaned HTML string
	 * @returns {string} The string without empty default lines
	 */
	#dropEmptyLines(html) {
		if (!this.#emptyLineRegExp.test(html)) return html;

		const holder = dom.utils.createElement('DIV', null, html);
		const lines = holder.querySelectorAll(this.#options.get('defaultLine'));
		let removed = false;
		for (let i = lines.length - 1; i >= 0; i--) {
			if (lines[i].firstChild) continue;
			dom.utils.removeItem(lines[i]);
			removed = true;
		}

		return removed ? holder.innerHTML : html;
	}

	/**
	 * @description Checks whether a node is a block-level container in which whitespace-only text
	 * children are insignificant formatting whitespace (safe to drop), as opposed to an inline/line
	 * @param {?Node} node Parent node of the whitespace text node (may be a `DocumentFragment`).
	 * @returns {boolean} `true` if the node is a block-level container.
	 */
	#isBlockLevelWhitespaceContext(node) {
		return (
			!node ||
			node.nodeType === 11 ||
			dom.check.isWysiwygFrame(node) ||
			dom.check.isList(node) ||
			dom.check.isTableElements(node) ||
			this.#$.format.isBlock(node)
		);
	}

	/**
	 * @description Fix tags that do not fit the editor format.
	 * @param {DocumentFragment} documentFragment Document fragment `DOCUMENT_FRAGMENT_NODE` (nodeType === 11)
	 * @param {RegExp} htmlCheckWhitelistRegExp Editor tags whitelist
	 * @param {RegExp} htmlCheckBlacklistRegExp Editor tags blacklist
	 * @param {boolean} tagFilter Tag filter option
	 * @param {boolean} formatFilter Format filter option
	 * @param {boolean} classFilter Class name filter option
	 * @param {boolean} _freeCodeViewMode Enforces strict HTML validation based on the editor`s policy
	 */
	#consistencyCheckOfHTML(
		documentFragment,
		htmlCheckWhitelistRegExp,
		htmlCheckBlacklistRegExp,
		tagFilter,
		formatFilter,
		classFilter,
		_freeCodeViewMode,
	) {
		const removeTags = [],
			emptyTags = [],
			wrongList = [],
			withoutFormatCells = [];

		// wrong position
		const wrongTags = dom.query.getListChildNodes(
			documentFragment,
			(current) => {
				if (current.nodeType !== 1) {
					if (formatFilter && dom.check.isList(current.parentElement)) removeTags.push(current);
					if (current.nodeType === 3) {
						// Remove empty text nodes, and collapsible whitespace-only nodes that render nothing
						if (
							!current.textContent ||
							(_RE_INSIGNIFICANT_WS.test(current.textContent) &&
								(this.#isBlockLevelWhitespaceContext(current.parentNode) ||
									!current.previousSibling !== !current.nextSibling))
						) {
							removeTags.push(current);
						}
					}
					return false;
				}

				// tag filter
				if (tagFilter) {
					// white list
					if (
						htmlCheckBlacklistRegExp.test(current.nodeName) ||
						(!htmlCheckWhitelistRegExp.test(current.nodeName) &&
							current.childNodes.length === 0 &&
							dom.check.isExcludeFormat(current))
					) {
						removeTags.push(current);
						return false;
					}
				}

				// code block: unwrap <pre><code class="language-xxx"> → <pre class="language-xxx">
				if (current.nodeName === 'PRE') this.#unwrapPreCode(current);

				const nrtag = !dom.query.getParentElement(current, dom.check.isExcludeFormat);

				// formatFilter
				if (formatFilter) {
					// empty tags
					if (
						!dom.check.isTableElements(current) &&
						!dom.check.isListCell(current) &&
						!dom.check.isAnchor(current) &&
						(this.#$.format.isLine(current) ||
							this.#$.format.isBlock(current) ||
							this.#$.format.isTextStyleNode(current)) &&
						current.childNodes.length === 0 &&
						nrtag
					) {
						emptyTags.push(current);
						return false;
					}

					// wrong list
					if (
						dom.check.isList(current.parentNode) &&
						!dom.check.isList(current) &&
						!dom.check.isListCell(current)
					) {
						wrongList.push(current);
						return false;
					}

					// table cells
					if (dom.check.isTableCell(current)) {
						const fel = current.firstElementChild;
						if (!this.#$.format.isLine(fel) && !this.#$.format.isBlock(fel) && !this.#$.component.is(fel)) {
							withoutFormatCells.push(current);
							return false;
						}
					}
				}

				// class filter
				if (classFilter) {
					if (nrtag && current.className) {
						const className = Array.from(current.classList).map(this.#isAllowedClassName).join(' ').trim();
						if (className) current.className = className;
						else current.removeAttribute('class');
					}
				}

				// format filter
				if (!formatFilter) {
					return false;
				}

				const result =
					!_freeCodeViewMode &&
					current.parentNode !== documentFragment &&
					nrtag &&
					((dom.check.isListCell(current) && !dom.check.isList(current.parentNode)) ||
						((this.#$.format.isLine(current) || this.#$.component.is(current)) &&
							!this.#$.format.isBlock(current.parentNode) &&
							!dom.query.getParentElement(current, this.#$.component.is.bind(this.#$.component))));

				return result;
			},
			null,
		);

		for (let i = 0, len = removeTags.length; i < len; i++) {
			dom.utils.removeItem(removeTags[i]);
		}

		const checkTags = [];
		for (let i = 0, len = wrongTags.length, t, p; i < len; i++) {
			t = wrongTags[i];
			p = t.parentNode;
			if (!p || !p.parentNode) continue;

			if (dom.query.getParentElement(t, dom.check.isListCell)) {
				const cellChildren = t.childNodes;
				for (let j = cellChildren.length - 1; j >= 0; j--) {
					p.insertBefore(cellChildren[j], t);
				}
				checkTags.push(t);
			} else {
				const ref = p.nextSibling;

				let rest = null;
				if (t.nextSibling) {
					rest = p.cloneNode(false);
					while (t.nextSibling) rest.appendChild(t.nextSibling);
				}

				p.parentNode.insertBefore(t, ref);

				if (rest) {
					p.parentNode.insertBefore(rest, ref);
					checkTags.push(rest);
				}
				checkTags.push(p);
			}
		}

		for (let i = 0, len = checkTags.length, t; i < len; i++) {
			t = checkTags[i];
			if (dom.check.isZeroWidth(t.textContent.trim())) {
				dom.utils.removeItem(t);
			}
		}

		for (let i = 0, len = emptyTags.length; i < len; i++) {
			dom.utils.removeItem(emptyTags[i]);
		}

		for (let i = 0, len = wrongList.length, t, tp, children, p; i < len; i++) {
			t = wrongList[i];
			p = t.parentNode;
			if (!p) continue;

			tp = dom.utils.createElement('LI');

			if (this.#$.format.isLine(t)) {
				children = t.childNodes;
				while (children[0]) {
					tp.appendChild(children[0]);
				}
				p.insertBefore(tp, t);
				dom.utils.removeItem(t);
			} else {
				t = t.nextSibling;
				tp.appendChild(wrongList[i]);
				p.insertBefore(tp, t);
			}
		}

		// wrap top-level `li` elements without a list parent in a `ul`
		if (formatFilter) {
			const orphanCells = dom.query.getListChildNodes(
				documentFragment,
				(current) => dom.check.isListCell(current) && !dom.check.isList(current.parentNode),
				null,
			);

			for (let i = 0, len = orphanCells.length, t, ul, n, next; i < len; i++) {
				t = orphanCells[i];
				if (dom.check.isList(t.parentNode)) continue;

				ul = dom.utils.createElement('UL');
				t.parentNode.insertBefore(ul, t);
				n = t;
				while (n && (dom.check.isListCell(n) || (n.nodeType === 3 && !n.textContent.trim()))) {
					next = n.nextSibling;
					ul.appendChild(n);
					n = next;
				}
			}
		}

		for (let i = 0, len = withoutFormatCells.length, t, f; i < len; i++) {
			t = withoutFormatCells[i];

			f = dom.utils.createElement('DIV');
			while (t.firstChild) f.appendChild(t.firstChild);

			if (f.textContent.trim().length === 0 && this.#isAllTextStyleNodes(f)) {
				let leaf = /** @type {Element} */ (f);
				while (leaf.firstElementChild) leaf = leaf.firstElementChild;
				leaf.innerHTML = '<br>';
			}

			t.appendChild(f);
		}
	}

	/**
	 * @description Checks if all element descendants are text-style nodes (no focusable non-text elements like br, img, etc.).
	 * @param {Element} el Target element
	 * @returns {boolean}
	 */
	#isAllTextStyleNodes(el) {
		const nodes = el.querySelectorAll('*');
		const format = this.#$.format;
		for (let i = 0; i < nodes.length; i++) {
			if (!format.isTextStyleNode(nodes[i])) return false;
		}
		return true;
	}

	/**
	 * @description Removes attribute values such as style and converts tags that do not conform to the `html5` standard.
	 * @param {string} html HTML string
	 * @returns {string} HTML string
	 */
	#styleNodeConvertor(html) {
		if (!this.#disallowedStyleNodesRegExp) return html;

		const ec = this.#options.get('_defaultStyleTagMap');
		return html.replace(this.#disallowedStyleNodesRegExp, (m, t, n, p) => {
			return t + (typeof ec[n] === 'string' ? ec[n] : n) + (p ? ' ' + p : '');
		});
	}

	/**
	 * @description Determines if formatting is required and returns a `domTree`
	 * @param {DocumentFragment} domFrag documentFragment
	 * @returns {DocumentFragment}
	 */
	#editFormat(domFrag) {
		let value = '',
			f;
		const tempTree = domFrag.childNodes;

		for (let i = 0, len = tempTree.length, n; i < len; i++) {
			n = /** @type {HTMLElement} */ (tempTree[i]);
			if (this.#allowedTagNameRegExp.test(n.nodeName)) {
				value += n.outerHTML;
				continue;
			}

			if (n.nodeType === 8) {
				value += '<!-- ' + n.textContent + ' -->';
			} else if (
				!/meta/i.test(n.nodeName) &&
				!this.#$.format.isLine(n) &&
				!this.#$.format.isBlock(n) &&
				!this.#$.component.is(n) &&
				!dom.check.isExcludeFormat(n)
			) {
				f ||= dom.utils.createElement(this.#options.get('defaultLine'));
				if (this.#$.format.isTextStyleNode(n)) {
					/** @type {HTMLElement} */
					(n).removeAttribute('style');
				}
				f.appendChild(n);
				i--;
				len--;
			} else {
				if (f) {
					value += f.outerHTML;
					f = null;
				}
				value += n.outerHTML;
			}
		}

		if (f) value += f.outerHTML;

		return _d.createRange().createContextualFragment(value);
	}

	/**
	 * @description Converts a list of DOM nodes into an HTML list structure.
	 * - If the node is already a list, its `innerHTML` is used. If it is a block element,
	 * - the function is called recursively.
	 * @param {SunEditor.NodeCollection} domTree List of DOM nodes to be converted.
	 * @returns {string} The generated HTML list.
	 */
	#convertListCell(domTree) {
		let html = '';

		for (let i = 0, len = domTree.length, node; i < len; i++) {
			node = domTree[i];
			if (node.nodeType === 1) {
				if (dom.check.isList(node)) {
					html += node.innerHTML;
				} else if (dom.check.isListCell(node)) {
					html += node.outerHTML;
				} else if (this.#$.format.isLine(node)) {
					html += '<li>' + (node.innerHTML.trim() || '<br>') + '</li>';
				} else if (this.#$.format.isBlock(node) && !dom.check.isTableElements(node)) {
					html += this.#convertListCell(node.children);
				} else {
					html += '<li>' + /** @type {HTMLElement} */ (node).outerHTML + '</li>';
				}
			} else {
				html += '<li>' + (node.textContent || '<br>') + '</li>';
			}
		}

		return html;
	}

	/**
	 * @description Checks whether the provided DOM nodes require formatting.
	 * @param {NodeList} domTree List of DOM nodes to check.
	 * @returns {boolean} `true` if formatting is required, otherwise `false`.
	 */
	#isFormatData(domTree) {
		let requireFormat = false;

		for (let i = 0, len = domTree.length, t; i < len; i++) {
			t = domTree[i];
			if (
				t.nodeType === 1 &&
				!this.#$.format.isTextStyleNode(t) &&
				!dom.check.isBreak(t) &&
				!this.#disallowedTagNameRegExp.test(t.nodeName)
			) {
				requireFormat = true;
				break;
			}
		}

		return requireFormat;
	}

	/**
	 * @description Cleans the inline style attributes of an HTML element.
	 * - Extracts allowed styles and removes disallowed ones based on editor settings.
	 * @param {string} m The full matched string from a regular expression.
	 * @param {?Array} v The list of allowed attributes.
	 * @param {string} name The tag name of the element being cleaned.
	 * @returns {Array} The updated list of allowed attributes including cleaned styles.
	 */
	#cleanStyle(m, v, name) {
		let sv = (m.match(_RE_STYLE_ATTR) || [])[0];
		if (this.#textStyleTags.includes(name) && !sv && (m.match(_RE_TAG_ATTRS) || [])[1]) {
			const size = (m.match(_RE_SIZE_ATTR) || [])[1];
			const face = (m.match(_RE_FACE_ATTR) || [])[1];
			const color = (m.match(_RE_COLOR_ATTR) || [])[1];
			if (size || face || color) {
				sv =
					'style="' +
					(size ? 'font-size:' + numbers.get(Number(size) / 3.333, 1) + 'rem;' : '') +
					(face ? 'font-family:' + face + ';' : '') +
					(color ? 'color:' + color + ';' : '') +
					'"';
			}
		}

		if (sv) {
			v ||= [];

			let mv;
			for (const [key, value] of this.#cleanStyleRegExpMap) {
				if (key.test(name)) {
					mv = value;
					break;
				}
			}
			if (!mv) return v;

			const style = sv.replace(_RE_AMP_QUOT, '').match(mv);
			if (!style) return v;

			const allowedStyle = [];
			for (let i = 0, len = style.length, r; i < len; i++) {
				r = style[i].match(_RE_CSS_PROP);
				if (r && !_RE_CSS_GLOBAL.test(r[3])) {
					const k = converter.kebabToCamelCase(r[1].trim());
					const cs = this.#frameContext.get('wwComputedStyle')[k]?.replace(_RE_DQUOTE, '');
					const c = r[3].trim();
					switch (k) {
						case 'fontFamily':
							if (!this.#$.plugins.font || !this.#$.plugins.font.fontArray.includes(c)) continue;
							break;
						case 'fontSize':
							if (!this.#$.plugins.fontSize) continue;
							if (!this.#fontSizeUnitRegExp.test(r[0])) {
								r[0] = r[0].replace(
									(r[0].match(_RE_CSS_VALUE) || [])[1],
									converter.toFontUnit.bind(null, this.#options.get('fontSizeUnits')[0]),
								);
							}
							break;
						case 'color':
							if (!this.#$.plugins.fontColor || _RE_TRANSPARENT_COLOR.test(c)) continue;
							break;
						case 'backgroundColor':
							if (!this.#$.plugins.backgroundColor || _RE_TRANSPARENT_COLOR.test(c)) continue;
							break;
					}

					if (cs !== c) {
						allowedStyle.push(r[0]);
					}
				}
			}
			if (allowedStyle.length > 0) v.push('style="' + allowedStyle.join(';') + '"');
		}

		return v;
	}

	/**
	 * @description Delete disallowed tags
	 * @param {string} html HTML string
	 * @returns {string}
	 */
	#deleteDisallowedTags(html, whitelistRegExp, blacklistRegExp) {
		if (whitelistRegExp.test('<font>')) {
			html = html.replace(/(<\/?)font(\s?)/gi, '$1span$2');
		}

		return html.replace(whitelistRegExp, '').replace(blacklistRegExp, '');
	}

	/**
	 * @description Removes the tags disallowed by `allowedExtraTags` (script, style, meta, link...).
	 * - Repeats until stable so a removal cannot join the remains into a new tag (`<scr<script></script>ipt>`).
	 * @param {string} html HTML string
	 * @returns {string}
	 */
	#removeDisallowedExtraTags(html) {
		for (let prev = null; prev !== html; ) {
			prev = html;
			html = html.replace(this.#disallowedTagsRegExp, '');
		}
		return html;
	}

	/**
	 * @description Recursively checks for duplicate text style nodes within a given parent node.
	 * @param {Node} oNode The node to check for duplicate styles.
	 * @param {Node} parentNode The parent node where the duplicate check occurs.
	 */
	#checkDuplicateNode(oNode, parentNode) {
		const recursionFunc = (current) => {
			this.#dupleCheck(current, parentNode);
			const childNodes = current.childNodes;
			for (let i = 0, len = childNodes.length; i < len; i++) {
				recursionFunc(childNodes[i]);
			}
		};
		recursionFunc(oNode);
	}

	/**
	 * @description Recursively checks for duplicate text style nodes within a given parent node.
	 * - If duplicate styles are found, redundant attributes are removed.
	 * @param {Node} oNode The node to check for duplicate styles.
	 * @param {Node} parentNode The parent node where the duplicate check occurs.
	 * @returns {Node} The cleaned node with redundant styles removed.
	 */
	#dupleCheck(oNode, parentNode) {
		if (!this.#$.format.isTextStyleNode(oNode)) return;

		const oStyles = (oNode.style.cssText.match(_RE_CSS_PARTS) || []).map(function (v) {
			return v.trim();
		});
		const nodeName = oNode.nodeName;
		if (_RE_SPAN.test(nodeName) && oStyles.length === 0) return oNode;

		const inst = this.#$.format;
		let duple = false;
		(function recursionFunc(ancestor) {
			if (dom.check.isWysiwygFrame(ancestor) || !inst.isTextStyleNode(ancestor)) return;
			if (ancestor.nodeName === nodeName) {
				duple = true;
				const styles = ancestor.style.cssText.match(_RE_CSS_PARTS) || [];
				for (let i = 0, len = styles.length, j; i < len; i++) {
					if ((j = oStyles.indexOf(styles[i].trim())) > -1) {
						oStyles.splice(j, 1);
					}
				}
				for (let i = 0, len = ancestor.classList.length; i < len; i++) {
					oNode.classList.remove(ancestor.classList[i]);
				}
			}

			recursionFunc(ancestor.parentElement);
		})(parentNode);

		if (duple) {
			if (!(oNode.style.cssText = oStyles.join(' '))) {
				oNode.setAttribute('style', '');
				oNode.removeAttribute('style');
			}
			if (oNode.attributes.length === 0) {
				oNode.setAttribute('data-duple', 'true');
			}
		}

		return oNode;
	}

	/**
	 * @description Tag and tag attribute check RegExp function.
	 * @param {string} m RegExp value
	 * @param {string} t RegExp value
	 * @returns {string}
	 */
	#CleanElements(attrFilter, styleFilter, m, t) {
		const nsTag = m.match(_RE_XML_NS_TAG);
		if (nsTag) t = nsTag[0];

		let v = null;
		const tagName = (nsTag ? t.substring(1) : t.match(_RE_TAG_NAME)[0]).toLowerCase();

		if (attrFilter) {
			// blacklist
			const bAttr = this.#attributeBlacklist[tagName];
			m = m.replace(_RE_ON_HANDLER, '');
			if (bAttr) m = m.replace(bAttr, '');
			else m = m.replace(this.#attributeBlacklistRegExp, '');

			// whitelist
			const wAttr = this.#attributeWhitelist[tagName];
			if (wAttr) v = m.match(wAttr);
			else v = m.match(this.#attributeWhitelistRegExp);

			if (tagName === 'a') {
				const sv = m.match(/(?:(?:id|name)\s*=\s*(?:"|')[^"']*(?:"|'))/g);
				if (sv) {
					v ||= [];
					v.push(sv[0]);
				}
			}
		} else {
			v = m.match(_RE_ANY_ATTR)?.filter((a) => !_RE_STYLE_NAME.test(a)) || null;
		}

		if (!styleFilter) {
			const sv = !v?.some((a) => _RE_STYLE_NAME.test(a)) && m.match(_RE_STYLE_ATTR_RAW);
			if (sv) {
				v ||= [];
				v.push(sv[0]);
			}
		} else if (tagName !== 'a' && !v?.some((a) => _RE_STYLE_NAME.test(a))) {
			if (_RE_SE_COMPONENT.test(m)) {
				v = this.#cleanStyle(m, v, '@component');
			} else if (this.#cleanStyleTagKeyRegExp.test(tagName)) {
				v = this.#cleanStyle(m, v, tagName);
			} else if (this.#$.format.isLine(tagName)) {
				v = this.#cleanStyle(m, v, '@line');
			} else if (this.#textStyleTags.includes(tagName)) {
				v = this.#cleanStyle(m, v, '@text');
			}
		}

		// figure
		if (styleFilter && (dom.check.isMedia(tagName) || dom.check.isFigure(tagName))) {
			const sv = m.match(_RE_STYLE_ATTR);
			v ||= [];
			if (sv) v.push(sv[0]);
		}

		if (v) {
			for (let i = 0, len = v.length, a; i < len; i++) {
				a = _isSafeAttribute(v[i].trim(), attrFilter, this.#allowedURLProtocols) ? v[i] : '';
				t += (_RE_LEADING_SPACE.test(a) ? '' : ' ') + a;
			}
		}

		return t;
	}

	/**
	 * @description Rebuilds an `<iframe>` from a clipboard placeholder (`data-se-iframe-holder-attrs`, see `helper/clipboard`).
	 * - event handlers, `srcdoc` and unsafe `src` are always dropped.
	 * @param {Element} placeholder Placeholder element
	 * @param {boolean} attrFilter `strictMode.attrFilter`
	 * @param {boolean} styleFilter `strictMode.styleFilter`
	 * @returns {?Element} The rebuilt iframe, or `null` when the placeholder is malformed
	 */
	#rebuildIframePlaceholder(placeholder, attrFilter, styleFilter) {
		let attrs = null;
		try {
			attrs = JSON.parse(placeholder.getAttribute('data-se-iframe-holder-attrs'));
		} catch {
			// malformed placeholder
		}
		if (!attrs || typeof attrs !== 'object' || Array.isArray(attrs)) return null;

		let tag = '<iframe';
		for (const [key, value] of Object.entries(attrs)) {
			if (!_RE_ATTR_NAME.test(key) || _RE_PLACEHOLDER_BLOCKED_ATTR.test(key)) continue;
			if (key === 'src' && !_isSafeURL(String(value), attrFilter, this.#allowedURLProtocols)) continue;
			tag += ` ${key}="${String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;')}"`;
		}

		tag = this.#CleanElements(attrFilter, styleFilter, tag, '<iframe');

		return _d.createRange().createContextualFragment(tag + '></iframe>').firstElementChild;
	}

	/**
	 * @internal
	 * @description Reset autoStyleify options.
	 * @param {Array.<string>} autoStyleify Styles applied automatically on text input.
	 * - ex `["bold", "underline", "italic", "strike"]`
	 */
	__resetAutoStyleify(autoStyleify) {
		if (autoStyleify.length > 0) {
			const convertTextTags = this.#options.get('convertTextTags');
			const styleToTag = {};
			autoStyleify.forEach((style) => {
				switch (style) {
					case 'bold':
						styleToTag.bold = { regex: /font-weight\s*:\s*bold/i, tag: convertTextTags.bold };
						break;
					case 'italic':
						styleToTag.italic = { regex: /font-style\s*:\s*italic/i, tag: convertTextTags.italic };
						break;
					case 'underline':
						styleToTag.underline = {
							regex: /text-decoration\s*:\s*underline/i,
							tag: convertTextTags.underline,
						};
						break;
					case 'strike':
						styleToTag.strike = {
							regex: /text-decoration\s*:\s*line-through/i,
							tag: convertTextTags.strike,
						};
						break;
				}
			});
			this.#autoStyleify = styleToTag;
		} else {
			this.#autoStyleify = null;
		}
	}

	/**
	 * @internal
	 * @description Destroy the HTML instance and release memory
	 */
	_destroy() {
		// Clear Map
		if (this.#cleanStyleRegExpMap) {
			this.#cleanStyleRegExpMap.clear();
		}
	}

	/**
	 * @description Input: unwrap `<pre><code class="language-xxx">` → `<pre class="language-xxx">`
	 * @param {HTMLElement} pre
	 */
	#unwrapPreCode(pre) {
		if (pre.children.length !== 1 || pre.firstElementChild?.nodeName !== 'CODE') return;

		const codeEl = pre.firstElementChild;
		const langMatch = (codeEl.className || '').match(/language-(\S+)/);

		if (langMatch && _RE_LANG_NAME.test(langMatch[1])) {
			dom.utils.addClass(pre, 'language-' + langMatch[1]);
			pre.setAttribute('data-se-lang', langMatch[1]);
		}

		while (codeEl.firstChild) {
			pre.insertBefore(codeEl.firstChild, codeEl);
		}

		pre.removeChild(codeEl);
	}

	/**
	 * @description Output: wrap `<pre class="language-xxx">` → `<pre><code class="language-xxx">`
	 * @param {HTMLElement} container
	 */
	#wrapPreCode(container) {
		const preEls = container.querySelectorAll('pre[class*="language-"]');

		for (let j = 0, jlen = preEls.length, pre, lang, codeEl; j < jlen; j++) {
			pre = preEls[j];
			lang = (pre.className.match(/language-(\S+)/) || [])[1];
			if (!lang) continue;

			codeEl = dom.utils.createElement('CODE', { class: 'language-' + lang });
			while (pre.firstChild) {
				codeEl.appendChild(pre.firstChild);
			}

			pre.appendChild(codeEl);
			pre.className = pre.className.replace(/\s*language-\S+/g, '').trim();
			pre.removeAttribute('data-se-lang');
		}
	}
}

/** Module-level regex constants */
// #unwrapPreCode: a code language is an identifier (`c++`, `c#`, `vb.net`)
const _RE_LANG_NAME = /^[\w+#.-]+$/;

// #CleanElements
const _RE_XML_NS_TAG = /^<[^\s/>:]+:[^\s/>]*/;
const _RE_TAG_NAME = /(?!<)[a-zA-Z0-9-]+/;
const _RE_ON_HANDLER = /\s(?:on[a-z]+)\s*=\s*(?:(["'])[^"']*\1|\S+)/gi;

// #rebuildIframePlaceholder
const _RE_ATTR_NAME = /^[a-z_][a-z0-9_.:-]*$/i;
const _RE_PLACEHOLDER_BLOCKED_ATTR = /^(?:on|srcdoc$)/i;
const _RE_STYLE_ATTR = /style\s*=\s*(?:"|')[^"']*(?:"|')/;
const _RE_STYLE_NAME = /^\s*style\s*=/i;
const _RE_STYLE_ATTR_RAW = /\sstyle\s*=\s*(?:"[^"]*"|'[^']*')/i;
const _RE_ANY_ATTR = /\s[^\s"'>/=]+\s*=\s*(?:"[^"]*"|'[^']*')/g;
const _RE_SE_COMPONENT = /class\s*=\s*("|')(?:[^"']*\s)?se-component(?=[\s"'])/i;
const _RE_LEADING_SPACE = /^\s/;

// #cleanStyle
const _RE_TAG_ATTRS = /<[^\s]+\s(.+)/;
// #consistencyCheckOfHTML: collapsible ASCII whitespace only (excludes &nbsp;/zero-width, which are meaningful content)
const _RE_INSIGNIFICANT_WS = /^[ \t\n\r\f\v]+$/;
const _RE_SIZE_ATTR = /\ssize="([^"]+)"/i;
const _RE_FACE_ATTR = /\sface="([^"]+)"/i;
const _RE_COLOR_ATTR = /\scolor="([^"]+)"/i;
const _RE_AMP_QUOT = /&quot;/g;
const _RE_CSS_PROP = /([a-zA-Z0-9-]+)(:)([^"']+)/;
const _RE_CSS_GLOBAL = /inherit|initial|revert|unset/i;
const _RE_DQUOTE = /"/g;
const _RE_CSS_VALUE = /:\s*([^;]+)/;
const _RE_TRANSPARENT_COLOR = /rgba\(([0-9]+\s*,\s*){3}0\)|windowtext/i;

// #dupleCheck
const _RE_CSS_PARTS = /[^;]+;/g;
const _RE_SPAN = /^span$/i;

// _isSafeAttribute
const _SAFE_URL_PROTOCOL = /^(?:https?|ftps?|mailto|tel|blob|sms|geo|webcal|callto):|^[#/]|^data:image\//i;
const _UNSAFE_URL_PROTOCOL = /^(?:javascript|vbscript):|^data:(?!image\/)/i;
const _RE_SCRIPT_ATTR = /^(?:on|srcdoc\s*=)/i;
const _URL_ATTR_PATTERN =
	/^(?:href|src|poster|xlink:href|background|cite|action|formaction|data|codebase|longdesc|srcset|imagesrcset|values|to|from)\s*=/i;

// candidate / keyframe lists — every entry is checked (`srcset`: `url 1x, url 2x`; SVG `values`: `a;b`)
const _URL_LIST_ATTR_PATTERN = /^(?:srcset|imagesrcset|values)\s*=/i;
const _RE_URL_LIST_SEPARATOR = /[,;]/;
const _RE_ATTR_VALUE = /=\s*(?:"([^"]*)"|'([^']*)'|(\S+))/;
const _RE_COLON = /:/i;

// _normalizeURL — entity decoder, created once on first use
/** @type {?HTMLTextAreaElement} */
let _entityDecoder = null;
const _RE_AMP_REF = /&(?:amp|AMP);/g;
const _RE_NON_AMP_REF = /&(?!(?:amp|AMP);)/;

/**
 * @description Normalize a URL by decoding all HTML entities, URL-encoded characters,
 * and stripping whitespace/control characters. Used to detect obfuscated dangerous protocols.
 * e.g. `java&#x09;script:`, `java%09script:`, `&#106;avascript:`, `javascript&colon;`, `javascript&#58alert`
 * @param {string} url Raw URL string
 * @returns {string} Normalized URL
 */
function _normalizeURL(url) {
	// <textarea> content is RCDATA: `innerHTML` decodes refs exactly like the browser (`&colon;`, `&#58`)
	// without creating elements — a hand-written decoder drifted and let `javascript:` through.
	if (_RE_NON_AMP_REF.test(url)) {
		_entityDecoder ||= _d.createElement('textarea');
		_entityDecoder.innerHTML = url;
		url = _entityDecoder.value;
	} else if (url.includes('&')) {
		url = url.replace(_RE_AMP_REF, '&');
	}

	// Decode URL-encoded characters (%09, %0a, etc.)
	try {
		url = decodeURIComponent(url);
	} catch {
		// malformed URI — keep as is
	}

	// Strip all whitespace and control characters (U+0000–U+0020)
	// eslint-disable-next-line no-control-regex -- intentional: strip control chars used to bypass protocol detection
	url = url.replace(/[\u0000-\u0020]+/g, '');

	return url;
}

/**
 * @description Check if a URL is safe.
 * - `strict` (attribute filter on): the protocol must be in the allowed whitelist.
 * - otherwise only script-capable protocols are rejected, so custom app schemes (`zoommtg:`, `slack:`) are kept.
 * @param {string} url Raw URL string
 * @param {boolean} [strict=true] Use the protocol whitelist
 * @param {Set<string>} [allowedProtocols] Additional allowed schemes
 * @returns {boolean}
 */
function _isSafeURL(url, strict = true, allowedProtocols) {
	const normalized = _normalizeURL(url);
	if (_UNSAFE_URL_PROTOCOL.test(normalized)) return false;
	if (!strict || _SAFE_URL_PROTOCOL.test(normalized) || !_RE_COLON.test(normalized)) return true;
	return !!allowedProtocols?.size && allowedProtocols.has(normalized.slice(0, normalized.indexOf(':')).toLowerCase());
}

/**
 * @description Checks whether an HTML attribute string is safe from XSS injection.
 * - Event handlers (`on*`) and `srcdoc` are never safe.
 * - Other non-URL attributes (anything not in `_URL_ATTR_PATTERN`: `href`, `src`, `srcset`, `action`, SVG `values`, ...) are safe.
 * - For URL attributes, extracts the URL value and delegates to {@link _isSafeURL}
 *   to verify the protocol (whitelist when `strict`, script-capable protocols otherwise).
 * @param {string} attr A single attribute string (e.g. `href="https://example.com"`, `class="foo"`)
 * @param {boolean} [strict=true] Use the protocol whitelist (`strictMode.attrFilter`)
 * @param {Set<string>} [allowedProtocols] Additional allowed schemes
 * @returns {boolean} `true` if the attribute is safe, `false` if it can run script.
 */
function _isSafeAttribute(attr, strict = true, allowedProtocols) {
	if (_RE_SCRIPT_ATTR.test(attr)) return false;
	if (!_URL_ATTR_PATTERN.test(attr)) return true;

	const urlMatch = attr.match(_RE_ATTR_VALUE);
	if (!urlMatch) return true;

	const url = urlMatch[1] ?? urlMatch[2] ?? urlMatch[3] ?? '';
	if (_URL_LIST_ATTR_PATTERN.test(attr)) {
		return url.split(_RE_URL_LIST_SEPARATOR).every((u) => _isSafeURL(u.trim(), strict, allowedProtocols));
	}
	return _isSafeURL(url, strict, allowedProtocols);
}

/**
 * @description Get related list
 * @param {string} str Regular expression string
 * @param {string} str2 Regular expression string
 */
function GetRegList(str, str2) {
	return !str ? '^' : str === '*' ? '[a-z-]+' : !str2 ? str : str + '|' + str2;
}

export default HTML;
