/**
 * @fileoverview Markdown converter module
 * - Supports GitHub Flavored Markdown (GFM) syntax
 *
 * @description Limitations — Style loss during roundtrip
 *
 * Markdown syntax cannot represent HTML inline styles, classes, or data attributes.
 * When switching between WYSIWYG and Markdown view, the following behavior applies:
 *
 * | Content type                        | Behavior                                    | Example                                              |
 * |-------------------------------------|---------------------------------------------|------------------------------------------------------|
 * | Media components (`div.se-component`) | Converted to markdown — styles are lost     | Image alignment, data-se-* attrs                     |
 * | Styled `<span>` elements            | Preserved as raw HTML in markdown           | Font color, background, custom classes               |
 * | Tables, figures                      | Converted to markdown — styles are lost     | Table cell styles, figure width, colgroup widths      |
 * | General elements (p, h1, blockquote) | Converted to markdown — styles are lost     | text-align, color, font-size on paragraphs/headings  |
 *
 * This is a fundamental limitation of the Markdown format.
 * To preserve all HTML attributes without loss, use Code View instead.
 */

const VOID_ELEMENTS = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)$/i;
const BLOCK_ELEMENTS =
	/^(address|article|aside|blockquote|div|dl|fieldset|figure|footer|form|h[1-6]|header|hr|main|nav|ol|p|pre|section|table|ul)$/i;
// A line starting with one of these tags is an HTML block; other tags are inline HTML in a paragraph.
const HTML_BLOCK_RE =
	/^\s*<\/?(address|article|aside|audio|blockquote|canvas|details|dialog|div|dl|fieldset|figcaption|figure|footer|form|h[1-6]|header|hr|iframe|main|nav|ol|p|pre|script|section|style|summary|table|textarea|ul|video)(?=[\s/>]|$)/i;
const ZERO_WIDTH_RE = /^[\u200B\uFEFF]+$/;
// Same word characters the parser checks around '_' emphasis.
const WORD_CHAR_RE = /[a-zA-Z0-9]/;
// A line matching this ends a paragraph and starts a block (heading, fence, quote, table, list, hr).
const PARAGRAPH_BREAK_RE = /^(#{1,6}\s|`{3,}|~{3,}|>|\||(\s*)([-*+]|\d+\.)\s|(\*{3,}|-{3,}|_{3,})\s*$)/;
// An empty list item ('-', '1.') starts a list, but cannot interrupt a paragraph.
const EMPTY_LIST_ITEM_RE = /^\s*([-*+]|\d+\.)\s*$/;
// An ordered list can interrupt a paragraph only when it starts with 1.
const ORDERED_ITEM_RE = /^\s*(\d+)\.\s/;
// Placeholder for an inline <br>; the block that holds it decides how to write it.
const BR_MARK = '\uE000';
const BR_MARK_RE = /\uE000/g;
// The text before a ']' that could close a task box ('[ ]', '[x]'), or a node start where a sibling may hold the '['.
const TASK_BOX_HEAD_RE = /^[ xX]?$|\[[ xX]$/;
// A string ending with a ']' that is not escaped.
const BRACKET_END_RE = /(?:^|[^\\])(?:\\\\)*\]$/;

// Inside link text ('[text](url)') or an image description ('![alt](src)') a ']' ends the text and a '[' opens
// a nested pair (CommonMark), so both are always escaped there.
let bracketTextDepth = 0;

/**
 * @description Run `fn` as link text / image description (see `bracketTextDepth`).
 * @param {() => string} fn
 * @returns {string}
 */
function asBracketText(fn) {
	bracketTextDepth++;
	try {
		return fn();
	} finally {
		bracketTextDepth--;
	}
}

/**
 * @description Check if a string is empty or contains only zero-width characters
 * @param {string} str
 * @returns {boolean}
 */
function isBlankLine(str) {
	const trimmed = str.trim();
	return trimmed === '' || ZERO_WIDTH_RE.test(trimmed);
}

/**
 * @description Inline tag to markdown syntax mapping
 */
const INLINE_WRAP_MAP = {
	strong: '**',
	b: '**',
	em: '*',
	i: '*',
	del: '~~',
	s: '~~',
	mark: '==',
};

/**
 * @description Escape the Markdown syntax in a text, only where it could be parsed as syntax.
 * - `*`, `` ` ``: always.
 * - `]`: before `(` or `:` (link, image, reference definition), closing a task box (`[ ]`, `[x]`).
 * - `[`, `]`: always in link text and an image description.
 * - `\`: before punctuation, a line break or at the end (next to other syntax).
 * - `_`: unless inside a word (`file_name`).
 * - `~`, `^`: when the text has a pair.
 * - `=`: before another `=`.
 * - `~`, `=`: also at the edges, where they touch the `~~` / `==` of a sibling.
 * - `<`, `&`: before a tag or an entity.
 * @param {string} str
 * @param {boolean} [isHtml=true] `false` when the result is HTML-escaped afterwards (`<`, `&` are then safe).
 * @returns {string}
 */
function escapeText(str, isHtml = true) {
	const hasTildePair = str.indexOf('~') !== str.lastIndexOf('~');
	const hasCaretPair = str.indexOf('^') !== str.lastIndexOf('^');
	const last = str.length - 1;
	let result = '';

	for (let i = 0; i <= last; i++) {
		const ch = str[i];
		const prev = str[i - 1] || '';
		const next = str[i + 1] || '';
		let escape = false;

		switch (ch) {
			case '\\':
				escape = !next || /[!-/:-@[-`{-~\r\n]/.test(next);
				break;
			case '*':
			case '`':
				escape = true;
				break;
			case '[':
				escape = bracketTextDepth > 0;
				break;
			case ']':
				escape = bracketTextDepth > 0 || next === '(' || next === ':' || TASK_BOX_HEAD_RE.test(str.slice(0, i));
				break;
			case '_':
				escape = !(WORD_CHAR_RE.test(prev) && WORD_CHAR_RE.test(next));
				break;
			case '~':
				escape = hasTildePair || i === 0 || i === last;
				break;
			case '^':
				escape = hasCaretPair;
				break;
			case '=':
				escape = next === '=' || i === 0 || i === last;
				break;
			case '<':
				escape = isHtml && /[a-zA-Z/!?]/.test(next);
				break;
			case '&':
				escape = isHtml && /^&(#\d+|#x[\da-f]+|\w+);/i.test(str.slice(i));
				break;
		}

		result += escape ? '\\' + ch : ch;
	}

	return result;
}

/**
 * @description Process children of a JSON node into inline markdown
 * @param {Array<Object>} children
 * @param {boolean} [isBlock=false]
 * @param {string} [indent='']
 * @returns {string}
 */
function childrenToInline(children, isBlock = false, indent = '') {
	if (!children || children.length === 0) return '';

	const parts = children.map((child, index) => {
		// HTML indentation next to blocks is not an inline word separator.
		if (
			child.type === 'text' &&
			/^[\t\n\r ]*$/.test(child.content) &&
			(BLOCK_ELEMENTS.test(children[index - 1]?.tag) || BLOCK_ELEMENTS.test(children[index + 1]?.tag))
		) {
			return '';
		}
		return nodeToMarkdown(child, indent, isBlock);
	});

	// Touching '*' markers are ambiguous (e.g. '*A***B**'), so keep the right one as HTML.
	for (let i = 1; i < parts.length; i++) {
		if (INLINE_WRAP_MAP[children[i].tag] && parts[i - 1].endsWith('*') && parts[i].startsWith('*')) {
			parts[i] = escapeLineBreaks(nodeToHtmlFallback(children[i], true));
		}
	}

	// A ']' ending one part and a '(' or ':' starting the next would form a link, so escape the ']'.
	for (let i = 1, prev = 0; i < parts.length; i++) {
		if (!parts[i]) continue;
		if (/^[(:]/.test(parts[i]) && BRACKET_END_RE.test(parts[prev])) {
			parts[prev] = parts[prev].slice(0, -1) + '\\]';
		}
		prev = i;
	}

	return parts.join('');
}

/**
 * @description Encode line breaks so inline content is not split into Markdown blocks.
 * @param {string} str
 * @returns {string}
 */
function escapeLineBreaks(str) {
	return str.replace(/\r/g, '&#13;').replace(/\n/g, '&#10;').replace(BR_MARK_RE, '<br>');
}

/**
 * @description Remove whitespace and `<br>` (empty line placeholder) from both ends of inline content.
 * @param {string} str
 * @returns {string}
 */
function trimLine(str) {
	return str.replace(/^[\s\uE000]+|[\s\uE000]+$/g, '');
}

/**
 * @description Escape a line that would start a Markdown block (list, heading, quote...).
 * @param {string} line
 * @returns {string}
 */
function escapeLineStart(line) {
	if (!PARAGRAPH_BREAK_RE.test(line) && !EMPTY_LIST_ITEM_RE.test(line)) return line;
	// '1.' -> '1\.' ('\1' is not an escape)
	if (/^\s*\d/.test(line)) return line.replace('.', '\\.');
	return line.replace(/\S/, '\\$&');
}

/**
 * @description Write inline content as the lines of a Markdown paragraph.
 * - `<br>` becomes a hard line break (`\` + newline); other line breaks stay as soft breaks.
 * - A line that would start a Markdown block stays in the paragraph.
 * @param {string} str
 * @returns {string}
 */
function toParagraph(str) {
	return (
		trimLine(str)
			// Whitespace around a line break is not rendered, and a blank line would end the paragraph.
			.replace(/[ \t\r]*\n(?:[ \t\r]*\n)*/g, '\n')
			.replace(/\n?\uE000\n?/g, BR_MARK)
			.replace(BR_MARK_RE, '\\\n')
			.split('\n')
			.map(escapeLineStart)
			.join('\n')
	);
}

/**
 * @description Process inline children into a single Markdown line (heading, list item, table cell).
 * - `<br>` between contents is kept as HTML; edge `<br>` (empty line placeholder) is dropped.
 * @param {Array<Object>} children
 * @returns {string}
 */
function childrenToLine(children) {
	return escapeLineBreaks(trimLine(childrenToInline(children)));
}

/**
 * @description Get text content from a JSON node recursively
 * @param {Object} node
 * @returns {string}
 */
function getTextContent(node) {
	if (!node) return '';
	if (node.type === 'text') return node.content || '';
	if (node.children) return node.children.map(getTextContent).join('');
	return '';
}

/**
 * @description Get the text of a code block; `<br>` (the editor's line break in `PRE`) becomes a newline.
 * @param {Object} node
 * @returns {string}
 */
function getCodeText(node) {
	if (!node) return '';
	if (node.type === 'text') return node.content || '';
	if (node.tag === 'br') return '\n';
	if (node.children) return node.children.map(getCodeText).join('');
	return '';
}

/**
 * @description Convert a JSON element node to its HTML string (for fallback)
 * @param {Object} node
 * @param {boolean} [isInline=false] Inline HTML is parsed with its line, so its text is Markdown-escaped too.
 * @returns {string}
 */
function nodeToHtmlFallback(node, isInline = false) {
	if (!node) return '';
	if (node.type === 'text') {
		const text = node.content || '';
		return escapeHtml(isInline ? escapeText(text, false) : text);
	}

	const { tag, attributes = {}, children = [] } = node;
	const attrStr = Object.entries(attributes)
		.map(([k, v]) => `${k}="${escapeHtml(String(v))}"`)
		.join(' ');
	const openTag = attrStr ? `<${tag} ${attrStr}>` : `<${tag}>`;

	if (VOID_ELEMENTS.test(tag)) return openTag;

	const inner = children.map((child) => nodeToHtmlFallback(child, isInline)).join('');
	return `${openTag}${inner}</${tag}>`;
}

/**
 * @description Whether a list subtree needs HTML to preserve a negative start number.
 * @param {Object} node
 * @returns {boolean}
 */
function hasNegativeListStart(node) {
	return (
		(node.tag === 'ol' && parseInt(node.attributes?.start, 10) < 0) ||
		(node.children || []).some(hasNegativeListStart)
	);
}

/**
 * @description Indent each line of a block string
 * @param {string} str
 * @param {string} indent
 * @returns {string}
 */
function indentBlock(str, indent) {
	if (!str) return '';
	return (
		str
			.split('\n')
			.map((line) => (line ? indent + line : ''))
			.join('\n') + '\n'
	);
}

/**
 * @description Convert a list JSON node (ul/ol) to markdown
 * @param {Object} node
 * @param {string} indent Current indentation
 * @param {boolean} isOrdered
 * @returns {string}
 */
function listToMarkdown(node, indent, isOrdered) {
	const children = node.children || [];
	let result = '';
	const start = parseInt(node.attributes?.start, 10);
	let index = isOrdered && !Number.isNaN(start) ? start : 1;
	// A loose list (<li><p>...</p></li>) keeps blank lines between its items.
	const isLoose = children.some(
		(li) => li.tag === 'li' && (li.children || []).some((c) => c.type === 'element' && c.tag === 'p'),
	);

	for (const child of children) {
		if (child.type !== 'element' || child.tag !== 'li') continue;

		const prefix = isOrdered ? `${index}. ` : '- ';
		let liChildren = child.children || [];
		// GFM puts the checkbox of a loose task item in its first paragraph.
		const firstP = liChildren[0];
		if (firstP?.tag === 'p' && firstP.children?.[0]?.tag === 'input') {
			liChildren = [...firstP.children, ...liChildren.slice(1)];
		}
		const inlineChildren = [];
		let subBlocks = '';
		const blockIndent = indent + ' '.repeat(prefix.length);

		// GFM task list: check for checkbox input
		let taskPrefix = '';
		const firstChild = liChildren[0];
		if (
			firstChild &&
			firstChild.type === 'element' &&
			firstChild.tag === 'input' &&
			firstChild.attributes?.type === 'checkbox'
		) {
			taskPrefix = firstChild.attributes.checked !== undefined ? '[x] ' : '[ ] ';
		}

		for (let ci = 0; ci < liChildren.length; ci++) {
			const liChild = liChildren[ci];
			// Skip checkbox input already handled
			if (ci === 0 && taskPrefix) continue;

			if (liChild.type !== 'element') {
				inlineChildren.push(liChild);
				continue;
			}

			const tag = liChild.tag;
			if (tag === 'ul' || tag === 'ol') {
				subBlocks += listToMarkdown(liChild, blockIndent, tag === 'ol');
			} else if (tag === 'table') {
				subBlocks += indentBlock(tableToMarkdown(liChild), blockIndent);
			} else if (tag === 'figure') {
				// figure wraps table/image in editor (e.g. <figure><table>...</table></figure>)
				const tableChild = (liChild.children || []).find((c) => c.type === 'element' && c.tag === 'table');
				if (tableChild) {
					subBlocks += indentBlock(tableToMarkdown(tableChild), blockIndent);
				} else {
					subBlocks += indentBlock(nodeToMarkdown(liChild, '', true), blockIndent);
				}
			} else if (tag === 'blockquote' || tag === 'pre') {
				subBlocks += indentBlock(nodeToMarkdown(liChild, '', true), blockIndent);
			} else {
				inlineChildren.push(liChild);
			}
		}

		if (isLoose && result) result += '\n';
		// An empty item is written as a bare marker ('-'), without trailing spaces.
		const itemLine = `${indent}${prefix}${taskPrefix}${childrenToLine(inlineChildren)}`.trimEnd();
		result += itemLine + '\n';
		if (subBlocks) result += (isLoose && itemLine !== indent + prefix.trimEnd() ? '\n' : '') + subBlocks;
		index++;
	}

	return result;
}

/**
 * @description Convert a table JSON node to markdown pipe table
 * @param {Object} node
 * @returns {string}
 */
function tableToMarkdown(node) {
	const rawRows = [];
	let hasHeader = false;

	// Collect raw rows from thead/tbody/tfoot or direct tr children
	function collectRows(parent, isHead) {
		for (const child of parent.children || []) {
			if (child.tag === 'thead') {
				collectRows(child, true);
			} else if (child.tag === 'tbody' || child.tag === 'tfoot') {
				collectRows(child, false);
			} else if (child.tag === 'tr') {
				const cells = [];
				for (const cell of child.children || []) {
					if (cell.tag === 'td' || cell.tag === 'th') {
						// '|' splits cells even inside code or HTML, so it is always escaped in a cell.
						const content = childrenToLine(cell.children || []).replace(/\|/g, '\\|');
						const colspan = parseInt(cell.attributes?.colspan, 10) || 1;
						const rowspan = parseInt(cell.attributes?.rowspan, 10) || 1;
						cells.push({ content, colspan, rowspan });
					}
				}
				const isHeaderRow = isHead || (!hasHeader && child.children?.some((c) => c.tag === 'th'));
				if (isHeaderRow) hasHeader = true;
				rawRows.push({ cells, isHeader: isHeaderRow });
			}
		}
	}

	collectRows(node, false);
	if (rawRows.length === 0) return '';

	// Move header rows to front
	const headerRows = rawRows.filter((r) => r.isHeader);
	const bodyRows = rawRows.filter((r) => !r.isHeader);
	const orderedRows = [...headerRows, ...bodyRows];

	// Determine column count by expanding colspan
	let colCount = 0;
	for (const row of orderedRows) {
		let count = 0;
		for (const cell of row.cells) {
			count += cell.colspan;
		}
		if (count > colCount) colCount = count;
	}

	// Build a 2D grid, expanding colspan and rowspan
	// null = unoccupied, string = occupied (content or empty string for spanned cells)
	const grid = Array.from({ length: orderedRows.length }, () => new Array(colCount).fill(null));

	for (let r = 0; r < orderedRows.length; r++) {
		let col = 0;
		for (const cell of orderedRows[r].cells) {
			// Skip columns already occupied by rowspan from above
			while (col < colCount && grid[r][col] !== null) col++;
			if (col >= colCount) break;

			// Fill colspan and rowspan cells
			for (let rs = 0; rs < cell.rowspan && r + rs < orderedRows.length; rs++) {
				for (let cs = 0; cs < cell.colspan && col + cs < colCount; cs++) {
					// Only put content in the first cell; spanned cells get empty string
					grid[r + rs][col + cs] = rs === 0 && cs === 0 ? cell.content : '';
				}
			}
			col += cell.colspan;
		}
		// Fill any remaining null cells with empty string
		for (let c = 0; c < colCount; c++) {
			if (grid[r][c] === null) grid[r][c] = '';
		}
	}

	let result = '';
	const hasHeaderRow = headerRows.length > 0;

	if (hasHeaderRow) {
		// Use actual header row
		result += '| ' + grid[0].join(' | ') + ' |\n';
		result += '| ' + grid[0].map(() => '---').join(' | ') + ' |\n';
		for (let r = 1; r < grid.length; r++) {
			result += '| ' + grid[r].join(' | ') + ' |\n';
		}
	} else {
		// No header: insert empty header row
		result += '| ' + new Array(colCount).fill(' ').join(' | ') + ' |\n';
		result += '| ' + new Array(colCount).fill('---').join(' | ') + ' |\n';
		for (let r = 0; r < grid.length; r++) {
			result += '| ' + grid[r].join(' | ') + ' |\n';
		}
	}

	return result;
}

/**
 * @description Convert a single JSON node to markdown
 * @param {Object} node JSON node from htmlToJson
 * @param {string} indent Current indentation for block-level
 * @param {boolean} isBlock Whether we're in block context
 * @returns {string}
 */
function nodeToMarkdown(node, indent, isBlock) {
	if (!node) return '';

	// Text node - strip zero-width characters (editor artifacts)
	if (node.type === 'text') {
		return escapeText((node.content || '').replace(/[\u200B\uFEFF]/g, ''));
	}

	if (node.type !== 'element') return '';

	const { tag, attributes = {}, children = [] } = node;

	// Body (root node from htmlToJson)
	if (tag === 'body') {
		return childrenToInline(children, true);
	}

	// Headings
	const headingMatch = /^h([1-6])$/.exec(tag);
	if (headingMatch) {
		const content = childrenToLine(children);
		if (!content) return '\n';
		const level = parseInt(headingMatch[1], 10);
		const prefix = '#'.repeat(level);
		return `${prefix} ${content}\n\n`;
	}

	if (tag === 'p') {
		const content = toParagraph(childrenToInline(children));
		// Empty paragraph
		if (!content) return '\n';
		return `${content}\n\n`;
	}

	if (tag === 'br') {
		return isBlock ? '\n' : BR_MARK;
	}

	if (tag === 'hr') {
		return '---\n\n';
	}

	// Inline formatting
	const wrapSyntax = INLINE_WRAP_MAP[tag];
	if (wrapSyntax) {
		const content = childrenToInline(children);
		// Spaces next to a marker break emphasis (e.g. '* word*' starts a list item), so keep them outside.
		const [, lead, body, trail] = /^((?:[^\S\r\n]|\uE000)*)([\s\S]*?)((?:[^\S\r\n]|\uE000)*)$/.exec(content);
		if (!body) return content;
		return `${lead}${wrapSyntax}${escapeLineBreaks(body)}${wrapSyntax}${trail}`;
	}

	// Inline code
	if (tag === 'code') {
		// A line break in inline code renders as a space, and must not start a new Markdown line.
		const content = getTextContent({ children }).replace(/\r?\n|\r/g, ' ');
		// Use double backticks if content contains backtick
		if (content.includes('`')) {
			return '`` ' + content + ' ``';
		}
		return '`' + content + '`';
	}

	// Keyboard input
	if (tag === 'kbd') {
		const content = getTextContent({ children });
		return `<kbd>${content}</kbd>`;
	}

	// Subscript / Superscript
	if (tag === 'sub') {
		const content = childrenToInline(children);
		return `<sub>${content}</sub>`;
	}
	if (tag === 'sup') {
		const content = childrenToInline(children);
		return `<sup>${content}</sup>`;
	}

	if (tag === 'a') {
		const href = attributes.href || '';
		const text = asBracketText(() => childrenToInline(children));
		const title = attributes.title;
		if (title) return `[${text}](${href} "${title}")`;
		return `[${text}](${href})`;
	}

	if (tag === 'img') {
		const src = attributes.src || '';
		const alt = asBracketText(() => escapeText(attributes.alt || ''));
		return `![${alt}](${src})`;
	}

	if (tag === 'blockquote') {
		const inner = childrenToInline(children, true);
		// Prefix each line with >
		const lines = inner.replace(/\n$/, '').split('\n');
		return lines.map((line) => `> ${line}`).join('\n') + '\n\n';
	}

	// Pre / code block
	if (tag === 'pre') {
		let lang = '';
		let codeContent = '';

		// Check if pre contains a code element
		const codeChild = children.find((c) => c.type === 'element' && c.tag === 'code');
		if (codeChild) {
			lang = (codeChild.attributes?.class || '').replace(/^language-/, '');
			codeContent = getCodeText(codeChild);
		} else {
			// Also check pre's own class for language- (editor internal format)
			lang = (node.attributes?.class || '').match(/language-(\S+)/)?.[1] || '';
			codeContent = getCodeText({ children });
		}

		// the editor ends a brLine with a placeholder <br>
		codeContent = codeContent.replace(/\n$/, '');
		return '```' + lang + '\n' + codeContent + '\n```\n\n';
	}

	// Details/Summary (GFM)
	if (tag === 'details') {
		return nodeToHtmlFallback(node) + '\n\n';
	}
	if (tag === 'summary') {
		return nodeToHtmlFallback(node);
	}

	// Lists
	if (tag === 'ul' || tag === 'ol') {
		// Preserve the entire outer list when a nested list cannot use Markdown markers.
		if (hasNegativeListStart(node)) return nodeToHtmlFallback(node) + '\n\n';
		return listToMarkdown(node, indent, tag === 'ol') + '\n';
	}

	if (tag === 'table') {
		return tableToMarkdown(node) + '\n';
	}

	if (tag === 'dl') {
		let result = '';
		for (const child of children) {
			if (child.type !== 'element') continue;
			if (child.tag === 'dt') {
				result += childrenToInline(child.children).trim() + '\n';
			} else if (child.tag === 'dd') {
				result += ': ' + childrenToInline(child.children).trim() + '\n';
			}
		}
		return result + '\n';
	}
	if (tag === 'dt' || tag === 'dd') {
		return childrenToInline(children).trim();
	}

	// Div - check for component containers, otherwise process children
	if (tag === 'div') {
		// Component containers - process inner content
		if (attributes.class && /se-component/.test(attributes.class)) {
			return childrenToInline(children, true, indent);
		}
		const content = childrenToInline(children);
		if (!isBlock) return content;
		// A div used as a line (defaultLine: 'div') is a paragraph.
		if (children.some((c) => BLOCK_ELEMENTS.test(c.tag))) return content + '\n\n';
		const line = toParagraph(content);
		return line ? line + '\n\n' : '\n';
	}

	// Span - pass through as inline (may contain styles)
	if (tag === 'span') {
		if (attributes.style || attributes.class) {
			return nodeToHtmlFallback(node, true);
		}
		return childrenToInline(children);
	}

	// Figure - process children (table, media)
	if (tag === 'figure') {
		const inner = childrenToInline(children, true, indent);
		return /\n$/.test(inner) ? inner : inner + '\n\n';
	}
	if (tag === 'figcaption') {
		const content = childrenToInline(children).trim();
		return content ? content + '\n\n' : '';
	}

	// Video / Audio / Iframe - fallback to HTML
	if (tag === 'video' || tag === 'audio' || tag === 'iframe') {
		return nodeToHtmlFallback(node) + '\n\n';
	}

	// Abbreviation
	if (tag === 'abbr') {
		return nodeToHtmlFallback(node, true);
	}

	// HTML fallback (a tag the parser does not read as an HTML block is parsed inline)
	return nodeToHtmlFallback(node, !HTML_BLOCK_RE.test('<' + tag));
}

/**
 * @description Converts a JSON tree (from htmlToJson) to a Markdown string.
 * @param {Object} jsonNode JSON node from htmlToJson
 * @returns {string} Markdown string
 * @example
 * const json = htmlToJson('<p><strong>Hello</strong> World</p>');
 * const md = jsonToMarkdown(json);
 * // '**Hello** World\n\n'
 */
export function jsonToMarkdown(jsonNode) {
	if (!jsonNode) return '';
	const result = nodeToMarkdown(jsonNode, '', true).replace(BR_MARK_RE, '<br>');
	// Trim trailing whitespace but keep final newline
	return result.replace(/\n{3,}/g, '\n\n').trim() + '\n';
}

// ========================================================================
// Markdown -> HTML Parser
// ========================================================================

/**
 * @description Parse inline markdown syntax to HTML
 * @param {string} text
 * @returns {string} HTML string
 */
function parseInline(text) {
	if (!text) return '';

	const placeholders = [];
	function hold(html) {
		placeholders.push(html);
		return '\uFFFC' + (placeholders.length - 1) + '\uFFFC';
	}

	// 1. Inline code — extract to placeholder so inner syntax (and escapes) is not parsed
	text = text.replace(/(?<!\\)``\s(.+?)\s``/g, (_, c) => hold('<code>' + escapeHtml(c) + '</code>'));
	text = text.replace(/(?<!\\)`([^`]+)`/g, (_, c) => hold('<code>' + escapeHtml(c) + '</code>'));

	// 2. Autolinks: <https://url> or <email@example.com>
	text = text.replace(/(?<!\\)<(https?:\/\/[^>]+)>/g, (_, url) => hold(`<a href="${url}">${url}</a>`));
	text = text.replace(/(?<!\\)<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/g, (_, email) =>
		hold(`<a href="mailto:${email}">${email}</a>`),
	);

	// 3. Inline HTML tags — kept as-is, so attributes (e.g. class="__se__") are not parsed
	text = text.replace(/(?<!\\)<\/?[a-zA-Z][^<>]*>/g, (tag) => hold(tag));

	// 4. Escape sequences: '\' + any ASCII punctuation
	text = text.replace(/\\([!-/:-@[-`{-~])/g, (_, ch) => hold(escapeHtml(ch)));

	// 4-1. Hard line breaks: '\' or two or more spaces before a newline
	text = text.replace(/(?:\\| {2,})\n/g, () => hold('<br>'));

	// 5. Images: ![alt](src "title") or ![alt](src)
	// The text may hold balanced '[...]' pairs; an unbalanced '[' starts a later link instead ('[a [b](u)').
	text = text.replace(
		/!\[([^[\]]*(?:\[[^[\]]*\][^[\]]*)*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g,
		(_, alt, src, title) => {
			return hold(title ? `<img src="${src}" alt="${alt}" title="${title}">` : `<img src="${src}" alt="${alt}">`);
		},
	);

	// 5-1. Links: [text](url "title") or [text](url)
	text = text.replace(/\[((?:[^[\]]|\[[^[\]]*\])+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, (_, t, url, title) => {
		return hold(title ? `<a href="${url}" title="${title}">${t}</a>` : `<a href="${url}">${t}</a>`);
	});

	// 6. GFM autolink: bare URLs (tag attributes are already held)
	text = text.replace(/(?<![="'\w/])(https?:\/\/[^\s<>\])"]+)/g, (_, url) => hold(`<a href="${url}">${url}</a>`));

	// 7. Strikethrough first (before single tilde subscript)
	text = text.replace(/~~(.+?)~~/g, '<del>$1</del>');

	// 8. Bold+italic: ***text*** or ___text___
	text = text.replace(/\*{3}(.+?)\*{3}/g, '<strong><em>$1</em></strong>');
	text = text.replace(/_{3}(.+?)_{3}/g, '<strong><em>$1</em></strong>');

	// 9. Bold: **text** or __text__
	text = text.replace(/\*{2}(.+?)\*{2}/g, '<strong>$1</strong>');
	text = text.replace(/_{2}(.+?)_{2}/g, '<strong>$1</strong>');

	// 10. Italic: *text* or _text_
	text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
	text = text.replace(/(?<![a-zA-Z0-9])_(.+?)_(?![a-zA-Z0-9])/g, '<em>$1</em>');

	// 11. GFM highlight: ==text==
	text = text.replace(/==(.+?)==/g, '<mark>$1</mark>');

	// 12. Superscript: ^text^
	text = text.replace(/\^([^\s^]+)\^/g, '<sup>$1</sup>');

	// 13. Subscript: ~text~ (single tilde only, after strikethrough is already consumed)
	text = text.replace(/(?<!~)~([^\s~]+)~(?!~)/g, '<sub>$1</sub>');

	// Restore all placeholders (a held link text can hold others)
	const restore = (str) => str.replace(/\uFFFC(\d+)\uFFFC/g, (_, idx) => restore(placeholders[parseInt(idx, 10)]));
	text = restore(text);

	return text;
}

/**
 * @description Parses a Markdown string into an HTML string.
 * - HTML tags in the markdown are passed through as-is (for fallback elements).
 * @param {string} md Markdown string
 * @param {string} [defaultLine='p'] Default block element tag
 * @returns {string} HTML string
 * @example
 * markdownToHtml('# Hello\n\n**bold** text');
 * // '<h1>Hello</h1><p><strong>bold</strong> text</p>'
 */
export function markdownToHtml(md, defaultLine) {
	if (!md) return '';
	if (!defaultLine) defaultLine = 'p';

	const lines = md.split('\n');
	const output = [];
	let i = 0;

	while (i < lines.length) {
		const line = lines[i];

		// Empty line (or zero-width-only line) - skip
		if (isBlankLine(line)) {
			i++;
			continue;
		}

		// Code fence: ``` or ~~~
		const fenceMatch = /^(`{3,}|~{3,})(\w*)/.exec(line);
		if (fenceMatch) {
			const fenceChar = fenceMatch[1].charAt(0);
			const fenceLen = fenceMatch[1].length;
			const lang = fenceMatch[2];
			const codeLines = [];
			i++;
			// Close fence must use same char and at least same length
			const closeRe = new RegExp('^' + (fenceChar === '`' ? '`' : '~') + '{' + fenceLen + ',}\\s*$');
			while (i < lines.length && !closeRe.test(lines[i])) {
				codeLines.push(lines[i]);
				i++;
			}
			i++; // skip closing fence
			const langAttr = lang ? ` class="language-${lang}"` : '';
			output.push(`<pre><code${langAttr}>${escapeHtml(codeLines.join('\n'))}</code></pre>`);
			continue;
		}

		// Heading: # ~ ######
		const headingMatch = /^(#{1,6})\s+(.+)/.exec(line);
		if (headingMatch) {
			const level = headingMatch[1].length;
			output.push(`<h${level}>${parseInline(headingMatch[2].trim())}</h${level}>`);
			i++;
			continue;
		}

		// Horizontal rule: ---, ***, ___
		if (/^(\*{3,}|-{3,}|_{3,})\s*$/.test(line)) {
			output.push('<hr>');
			i++;
			continue;
		}

		// Blockquote
		if (/^>\s?/.test(line)) {
			const quoteLines = [];
			while (i < lines.length && /^>\s?/.test(lines[i])) {
				quoteLines.push(lines[i].replace(/^>\s?/, ''));
				i++;
			}
			const innerHtml = markdownToHtml(quoteLines.join('\n'), defaultLine);
			output.push(`<blockquote>${innerHtml}</blockquote>`);
			continue;
		}

		// Table
		if (/^\|.*\|/.test(line) && i + 1 < lines.length && /^\|[\s:]*-{3,}[\s:]*/.test(lines[i + 1])) {
			const tableLines = [];
			while (i < lines.length && /^\|.*\|/.test(lines[i])) {
				tableLines.push(lines[i]);
				i++;
			}
			output.push(parseTable(tableLines));
			continue;
		}

		// Unordered list: - item, * item, + item
		if (/^(\s*)([-*+])(\s+|$)/.test(line)) {
			const result = parseList(lines, i, false);
			output.push(result.html);
			i = result.index;
			continue;
		}

		// Ordered list: 1. item
		if (/^(\s*)\d+\.(\s+|$)/.test(line)) {
			const result = parseList(lines, i, true);
			output.push(result.html);
			i = result.index;
			continue;
		}

		// HTML block pass-through (starts with a block tag)
		if (HTML_BLOCK_RE.test(line)) {
			// Collect all lines until we find the closing or a blank line
			let htmlBlock = line;
			i++;
			// If it's a self-closing or known void element, just pass it
			if (VOID_ELEMENTS.test(line.match(/<(\w+)/)?.[1] || '')) {
				output.push(htmlBlock);
				continue;
			}
			// For block-level HTML, collect until blank line
			while (i < lines.length && !isBlankLine(lines[i])) {
				htmlBlock += '\n' + lines[i];
				i++;
			}
			output.push(htmlBlock);
			continue;
		}

		// Paragraph (default)
		const paraLines = [];
		while (i < lines.length && !isBlankLine(lines[i])) {
			const orderedMatch = paraLines.length > 0 && ORDERED_ITEM_RE.exec(lines[i]);
			if (PARAGRAPH_BREAK_RE.test(lines[i]) && !(orderedMatch && parseInt(orderedMatch[1], 10) !== 1)) break;
			paraLines.push(lines[i]);
			i++;
		}
		if (paraLines.length > 0) {
			const content = parseInline(paraLines.join('\n'));
			output.push(`<${defaultLine}>${content}</${defaultLine}>`);
		} else {
			// Line matched a block-break pattern but no handler caught it (e.g., "|" without table separator)
			output.push(`<${defaultLine}>${parseInline(lines[i])}</${defaultLine}>`);
			i++;
		}
	}

	return output.join('');
}

/**
 * @description Parse markdown table lines into HTML table
 * @param {string[]} tableLines
 * @returns {string}
 */
function parseTable(tableLines) {
	if (tableLines.length < 2) return '';

	const parseRow = (line) =>
		line
			.replace(/^\|/, '')
			.replace(/\|$/, '')
			.split(/(?<!\\)\|/)
			.map((c) => c.trim().replace(/\\\|/g, '|'));

	const headers = parseRow(tableLines[0]);
	// Parse separator line for alignment
	const separators = parseRow(tableLines[1]);
	const aligns = separators.map((sep) => {
		const trimmed = sep.trim();
		if (/^:-+:$/.test(trimmed)) return 'center';
		if (/^-+:$/.test(trimmed)) return 'right';
		if (/^:-+$/.test(trimmed)) return 'left';
		return '';
	});

	const rows = tableLines.slice(2).map(parseRow);
	const colCount = headers.length;

	// Check if header row is empty (all cells blank)
	const isEmptyHeader = headers.every((h) => h === '');

	let html = '<table>';

	const alignAttr = (idx) => {
		const a = aligns[idx];
		return a ? ` style="text-align: ${a};"` : '';
	};

	if (!isEmptyHeader) {
		html += '<thead><tr>';
		for (let c = 0; c < colCount; c++) {
			html += `<th${alignAttr(c)}>${parseInline(headers[c])}</th>`;
		}
		html += '</tr></thead>';
	}

	if (rows.length > 0 || isEmptyHeader) {
		html += '<tbody>';
		for (const row of rows) {
			html += '<tr>';
			for (let c = 0; c < colCount; c++) {
				html += `<td${alignAttr(c)}>${parseInline(row[c] || '')}</td>`;
			}
			html += '</tr>';
		}
		html += '</tbody>';
	}

	html += '</table>';
	return html;
}

/**
 * @description Parse markdown list into HTML
 * @param {string[]} lines
 * @param {number} startIndex
 * @param {boolean} ordered
 * @returns {{ html: string, index: number }}
 */
function parseList(lines, startIndex, ordered) {
	const tag = ordered ? 'ol' : 'ul';
	const itemPattern = ordered ? /^(\s*)\d+\.(?:\s+|$)(.*)/ : /^(\s*)([-*+])(?:\s+|$)(.*)/;
	const start = ordered ? parseInt(lines[startIndex].trimStart(), 10) : 1;
	const items = [];
	// A list is loose when blank lines separate its items or the blocks inside an item.
	let isLoose = false;
	let i = startIndex;
	const baseIndent = (lines[i].match(/^(\s*)/)[1] || '').length;

	while (i < lines.length) {
		const line = lines[i];
		if (isBlankLine(line)) {
			i++;
			continue;
		}

		const currentIndent = (line.match(/^(\s*)/)[1] || '').length;

		// If less indented than base, we're done
		if (currentIndent < baseIndent) break;

		// If at base level, check if it matches our list pattern
		if (currentIndent === baseIndent) {
			const match = itemPattern.exec(line);
			if (!match) break;
			if (i > startIndex && isBlankLine(lines[i - 1])) isLoose = true;

			const content = ordered ? line.replace(/^\s*\d+\.(\s+|$)/, '') : line.replace(/^\s*[-*+](\s+|$)/, '');
			i++;

			// GFM task list checkbox
			let isTask = false;
			let taskChecked = false;
			let displayContent = content;
			const taskMatch = /^\[([ xX])\]\s*(.*)/.exec(content);
			if (taskMatch) {
				isTask = true;
				taskChecked = taskMatch[1] !== ' ';
				displayContent = taskMatch[2];
			}

			// Collect nested blocks (sublists, tables, etc.) that are more indented
			let nestedHtml = '';
			while (i < lines.length) {
				const nextLine = lines[i];
				if (isBlankLine(nextLine)) {
					i++;
					continue;
				}
				const nextIndent = (nextLine.match(/^(\s*)/)[1] || '').length;
				if (nextIndent <= baseIndent) break;
				const afterBlank = isBlankLine(lines[i - 1]);

				// Nested list
				if (/^\s*([-*+]|\d+\.)(\s+|$)/.test(nextLine)) {
					const nested = parseList(lines, i, /^\s*\d+\./.test(nextLine));
					if (afterBlank) isLoose = true;
					nestedHtml += nested.html;
					i = nested.index;
					continue;
				}

				// Nested table (indented pipe table)
				const trimmedLine = nextLine.trimStart();
				if (/^\|.*\|/.test(trimmedLine) && i + 1 < lines.length && /^\s*\|[\s:]*-{3,}/.test(lines[i + 1])) {
					const tableLines = [];
					while (i < lines.length) {
						const tl = lines[i];
						if (isBlankLine(tl) || (tl.match(/^(\s*)/)[1] || '').length <= baseIndent) break;
						if (!/^\s*\|/.test(tl)) break;
						tableLines.push(tl.trimStart());
						i++;
					}
					if (afterBlank) isLoose = true;
					nestedHtml += parseTable(tableLines);
					continue;
				}

				// Other indented content — treat as continuation
				break;
			}

			if (isTask) {
				const checkbox = taskChecked
					? '<input type="checkbox" checked disabled> '
					: '<input type="checkbox" disabled> ';
				items.push({
					cls: ' class="task-list-item"',
					text: `${checkbox}${parseInline(displayContent)}`,
					nestedHtml,
				});
			} else {
				items.push({ cls: '', text: parseInline(content), nestedHtml });
			}
		} else {
			// More indented - this shouldn't happen if nested blocks are handled above
			break;
		}
	}

	let html = ordered && start !== 1 ? `<ol start="${start}">` : `<${tag}>`;
	for (const { cls, text, nestedHtml } of items) {
		// A loose item wraps its text in <p>; an empty item has no paragraph.
		html += `<li${cls}>${isLoose && text ? `<p>${text}</p>` : text}${nestedHtml}</li>`;
	}
	html += `</${tag}>`;
	return { html, index: i };
}

/**
 * @description Escape HTML special characters
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
	return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

const markdown = {
	jsonToMarkdown,
	markdownToHtml,
};

export default markdown;
