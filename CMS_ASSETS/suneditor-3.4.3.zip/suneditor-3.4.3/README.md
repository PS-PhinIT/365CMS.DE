<p align="center">
  <a href="https://suneditor.com" target="_blank">
    <img src="https://suneditor-files.s3.ap-northeast-2.amazonaws.com/docs/se3_logo_title_flat.svg?v=1" alt="SunEditor" width="280" />
  </a>
</p>

<p align="center"><strong>A modular WYSIWYG HTML editor with zero runtime dependencies.</strong><br /><em>Everything included. Enable only what you need.</em></p>

<p align="center">
	<a href="https://github.com/JiHong88/SunEditor/blob/master/LICENSE.txt" title="MIT License"><img src="https://img.shields.io/github/license/jihong88/suneditor.svg?style=flat-square" alt="GitHub License"></a>
	<a href="https://www.npmjs.com/package/suneditor" title="npm release"><img src="https://img.shields.io/npm/v/suneditor.svg?style=flat-square" alt="npm"></a>
	<a href="https://www.npmjs.com/package/suneditor" title="npm month downloads"><img src="https://img.shields.io/npm/dm/suneditor.svg?logo=npm&style=flat-square" alt="npm monthly downloads"></a>
	<a href="https://www.jsdelivr.com/package/npm/suneditor" title="jsDelivr CDN month downloads"><img src="https://img.shields.io/jsdelivr/npm/hm/suneditor?label=CDN&style=flat-square" alt="jsDelivr CDN" /></a>
	<a href="https://codecov.io/gh/jihong88/suneditor" title="Test coverage"><img src="https://codecov.io/gh/jihong88/suneditor/branch/develop/graph/badge.svg" alt="Test coverage" /></a>
</p>

<p align="center">
	<a href="https://suneditor.com/playground"><strong>Live Playground</strong></a> ·
	<a href="https://suneditor.com"><strong>Documentation</strong></a> ·
	<a href="#-install--quick-start"><strong>Get Started</strong></a> ·
	<a href="#react"><strong>React</strong></a>
</p>

<p align="center"><a href="https://github.com/suneditor/suneditor-react"><img align="absmiddle" height="24" src="https://img.shields.io/badge/React-%40suneditor%2Fsuneditor--react-555?style=flat-square&logo=react&logoColor=61DAFB&labelColor=20232a" alt="@suneditor/suneditor-react" /></a> Official component, Next.js ready</p>

#

- **Tables, images, video, audio and files** — resize, align, captions, galleries and uploads built in
- **Markdown, math and code blocks** — GFM Markdown view, LaTeX math, code blocks with a language selector
- **Slash commands and block handles** — `/` command menu, drag handles to move blocks
- **Mentions, find & replace, templates, PDF export, drawing** — and more, as opt-in plugins
- **TypeScript** — bundled type definitions for options, plugins and the public API
- **Works with any framework** — React, Vue, Angular, Svelte or plain HTML
- **MIT License** — free for commercial use, no account or cloud service required
- **Zero runtime dependencies** — no polyfills, no peer dependencies

## 🤔 Need an editor, not an editor framework?

Headless editor frameworks (Tiptap, Lexical, ProseMirror) give you an engine and leave the toolbar, dialogs,
tables and media handling for you to build. That is the right choice when the editor **is** your product.

SunEditor is for the other case: you need a complete HTML editor in a CMS, admin panel, back office,
board, product description or email form — and you need it today.

|                              | SunEditor                      | Headless editor framework              |
| ---------------------------- | ------------------------------ | -------------------------------------- |
| Toolbar, dialogs, menus      | Built in                       | You build them                         |
| Tables, images, media, files | Built in                       | Extensions + your own UI               |
| Output                       | HTML                           | Document model (HTML via a serializer) |
| First working editor         | One `create()` call            | Engine setup + your own UI             |
| Best for                     | CMS, admin, back office, forms | Notion-like or highly custom editors   |

**When SunEditor is not the best fit:** Notion-like block products, deeply custom node UIs, or collaboration-first
editors are better served by Tiptap or Lexical. Enterprise document workflows that need comments, track changes and
vendor support are better served by CKEditor.

### 📝 Content Editing Approach

SunEditor is optimized for **structured content** (articles, documentation, emails) rather than arbitrary HTML editing. Content is validated and auto-corrected to maintain consistency.

> For raw HTML editing needs, see [`strictMode` configuration](./ARCHITECTURE.md#content-filtering-strictmode) in the Architecture Guide.

🌤 **[Try all plugins in Playground](https://suneditor.com/playground)**

⭐ If SunEditor saves you time, a [GitHub star](https://github.com/JiHong88/SunEditor) helps other developers find it.

🤝 **Contributions welcome!** See the [Contribution Guidelines](/CONTRIBUTING.md) and the
[`good first issue`](https://github.com/jihong88/suneditor/issues?q=is%3Aopen+is%3Aissue+label%3A%22good+first+issue%22) /
[`help wanted`](https://github.com/jihong88/suneditor/issues?q=is%3Aopen+is%3Aissue+label%3A%22help+wanted%22) issues.

---

## 🌍 Browser Support

SunEditor is built to take advantage of modern browser capabilities.  
It does not ship with polyfills by default, but you can add them if your project requires broader compatibility.

> Works correctly on the following versions or newer.

| Browser                                                                                                                             | ≥ Version       |
| ----------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| ![Chrome](https://img.shields.io/badge/-Chrome-4285F4?logo=GoogleChrome&logoColor=white&style=flat-square)                          | 119 (Oct 2023)  |
| ![Edge](https://img.shields.io/badge/-Edge-0078D7?logo=MicrosoftEdge&logoColor=white&style=flat-square)                             | 119 (Nov 2023)  |
| ![Firefox](https://img.shields.io/badge/-Firefox-FF7139?logo=FirefoxBrowser&logoColor=white&style=flat-square)                      | 125 (Apr 2024)  |
| ![Safari (macOS, iOS)](https://img.shields.io/badge/-Safari-0D96F6?logo=Safari&logoColor=white&style=flat-square)                   | 17.2 (Dec 2023) |
| ![Opera](https://img.shields.io/badge/-Opera-FF1B2D?logo=Opera&logoColor=white&style=flat-square)                                   | 105 (Nov 2023)  |
| ![Android WebView](https://img.shields.io/badge/-Android%20WebView-3DDC84?logo=android&logoColor=white&style=flat-square)           | 119 (Oct 2023)  |
| ![Samsung Internet](https://img.shields.io/badge/-Samsung%20Internet-1428A0?logo=samsunginternet&logoColor=white&style=flat-square) | 23.0 (Oct 2023) |
| ![Firefox ESR](https://img.shields.io/badge/-FirefoxESR-FF7139?logo=FirefoxBrowser&logoColor=white&style=flat-square)               | 128 (Jul 2024)  |

❌ Not Supported : IE, Legacy Edge

### 📌 Why This Baseline? (Late 2023)

- This is based on features commonly supported by modern browsers.
- Most modern web APIs and CSS features are supported reliably in versions after this point.
- Unless specific compatibility issues arise, you can use it out of the box without additional polyfills.
- If you need support for older browsers, you can extend it by adding your own polyfills.

---

## 📦 Legacy Version (v2-legacy)

\* Supported IE11

> **SunEditor v3 is the latest version.**  
> This section refers to the **previous stable version, SunEditor v2**.

The `v2-legacy` branch is no longer actively maintained,  
but still available for compatibility with older projects.

👉 [`v2-legacy` branch](https://github.com/JiHong88/SunEditor/tree/v2-legacy)

---

## 🚀 Install & Quick Start

> 💡 **Want to see it in action?**  
> Check out the 🌤 [**Live Demo**](https://suneditor.com) 🌤 with full options and examples.

### NPM

```bash
npm install suneditor --save
```

```js
import 'suneditor/css/editor'; // Editor UI
import 'suneditor/css/contents'; // For displaying HTML
import suneditor from 'suneditor';

// HTML: <div id="editor"></div> or <textarea id="editor"></textarea>
suneditor.create(document.querySelector('#editor'), {
	// options
});
```

### React

```bash
npm install suneditor @suneditor/suneditor-react
```

```tsx
import SunEditor from '@suneditor/suneditor-react';
import 'suneditor/css/editor';
import 'suneditor/css/contents';

<SunEditor options={(se) => ({ plugins: [se.plugins.image], height: '400px' })} />;
```

Props, controlled value and Next.js usage: [suneditor-react README](https://github.com/suneditor/suneditor-react)

### CDN ([jsDelivr](https://www.jsdelivr.com/package/npm/suneditor))

```html
<script src="https://cdn.jsdelivr.net/npm/suneditor@latest/dist/suneditor.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/suneditor@latest/dist/suneditor.min.css" rel="stylesheet" />
<!-- Optional language (default is English): e.g., Korean (ko) -->
<!-- <script src="https://cdn.jsdelivr.net/npm/suneditor@latest/src/langs/ko.js"></script> -->

<div id="editor"></div>
<!-- or <textarea id="editor"></textarea> -->

<script>
	SUNEDITOR.create(document.querySelector('#editor'), {
		// options
	});
</script>
```

---

## 📦 Plugins

SunEditor supports a plugin-based architecture.\
You can enable only the plugins you need or even create your own custom ones.

Pass the plugins you want as an array of plugin classes:

```js
import suneditor from 'suneditor';
import { font, image, video } from 'suneditor/plugins';

suneditor.create('#editor', {
	plugins: [font, image, video],
	image: {
		uploadUrl: 'https://upload.image',
	},
});
```

An object keyed by plugin name works too, and `excludedPlugins` lets you drop
individual plugins when you enable the whole set:

```js
import plugins from 'suneditor/plugins';

suneditor.create('#editor', {
	plugins, // every built-in plugin
	excludedPlugins: ['image', 'video'],
});
```

📘 [Learn how to build your own plugin →](https://suneditor.com/plugin-guide)

### Community plugins

| Package   | Naming                                                               | Published by                                                    |
| --------- | -------------------------------------------------------------------- | --------------------------------------------------------------- |
| Official  | `@suneditor/<name>` (e.g. `@suneditor/plugin-mermaid`)               | The [suneditor](https://github.com/suneditor) organization only |
| Community | `suneditor-plugin-<name>` or `@<your-scope>/suneditor-plugin-<name>` | Anyone                                                          |

Add the `suneditor` and `suneditor-plugin` keywords so others can find your plugin, and share it in
[Discussions → Show and tell](https://github.com/JiHong88/SunEditor/discussions/categories/show-and-tell).

🤖 Want to build plugins? Get real-time help from [SunEditor Devs AI](https://chatgpt.com/g/g-JViNPCrkD-suneditor-devs).\
See [Contribution Guide](./CONTRIBUTING.md#-ai-plugin-helper) for tips and examples.

---

## ✨ Contributors

<a href="https://github.com/jihong88/suneditor/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=jihong88/suneditor" alt="contributors"/>
</a>

---

## 💎 Sponsors

### Backers

[![Backers on Open Collective](https://opencollective.com/suneditor/backers.svg?width=890&avatarHeight=64&button=false)](https://opencollective.com/suneditor)

### Sponsors

[![Sponsors on Open Collective](https://opencollective.com/suneditor/sponsors.svg?width=890&avatarHeight=64&button=false)](https://opencollective.com/suneditor)

---

## 🔒 Security

SunEditor sanitizes HTML on input, paste and Code View, and an XSS regression corpus runs with the unit test suite in CI.
Please report vulnerabilities privately — see the [Security Policy](./SECURITY.md).

---

## 📄 License

SunEditor is an open-source project available under the [MIT License](./LICENSE.txt).
